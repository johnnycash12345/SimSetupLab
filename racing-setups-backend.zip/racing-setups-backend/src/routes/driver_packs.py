from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.driver_packs import DriverPack, DriverPackSetup, DriverPackSubscription, DriverPackRating, PremiumFeature
from src.models.setup import Setup
from sqlalchemy import desc, and_, or_
from datetime import datetime, timedelta
import calendar

driver_packs_bp = Blueprint('driver_packs', __name__)

# Driver Packs Routes
@driver_packs_bp.route('/driver-packs', methods=['GET'])
def get_driver_packs():
    """Get all active driver packs"""
    try:
        category = request.args.get('category')  # rookie, professional, legend, superstar
        game_id = request.args.get('game_id', type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        sort_by = request.args.get('sort_by', 'popularity')  # popularity, price_low, price_high, newest
        
        query = DriverPack.query.filter_by(is_active=True)
        
        # Filtros
        if category:
            query = query.filter_by(driver_category=category)
        
        if game_id:
            query = query.filter(DriverPack.supported_games.contains([game_id]))
        
        # Ordenação
        if sort_by == 'popularity':
            query = query.order_by(desc(DriverPack.subscriber_count))
        elif sort_by == 'price_low':
            query = query.order_by(DriverPack.monthly_price.asc())
        elif sort_by == 'price_high':
            query = query.order_by(DriverPack.monthly_price.desc())
        elif sort_by == 'newest':
            query = query.order_by(desc(DriverPack.created_at))
        elif sort_by == 'rating':
            query = query.order_by(desc(DriverPack.rating_average))
        
        packs = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'driver_packs': [pack.to_dict() for pack in packs.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': packs.total,
                'pages': packs.pages,
                'has_next': packs.has_next,
                'has_prev': packs.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs', methods=['POST'])
def create_driver_pack():
    """Create a new driver pack"""
    try:
        data = request.get_json()
        
        required_fields = ['driver_name', 'pack_name', 'monthly_price']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        pack = DriverPack(
            driver_name=data['driver_name'],
            driver_bio=data.get('driver_bio'),
            driver_photo_url=data.get('driver_photo_url'),
            driver_nationality=data.get('driver_nationality'),
            driver_category=data.get('driver_category', 'professional'),
            pack_name=data['pack_name'],
            pack_description=data.get('pack_description'),
            pack_image_url=data.get('pack_image_url'),
            monthly_price=data['monthly_price'],
            yearly_price=data.get('yearly_price'),
            supported_games=data.get('supported_games', [])
        )
        
        db.session.add(pack)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'driver_pack': pack.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs/<int:pack_id>', methods=['GET'])
def get_driver_pack(pack_id):
    """Get a specific driver pack with its setups"""
    try:
        pack = DriverPack.query.get_or_404(pack_id)
        
        # Get pack setups
        pack_setups = DriverPackSetup.query.filter_by(driver_pack_id=pack_id)\
            .order_by(desc(DriverPackSetup.is_featured), desc(DriverPackSetup.created_at))\
            .all()
        
        # Get recent ratings
        recent_ratings = DriverPackRating.query.filter_by(driver_pack_id=pack_id)\
            .order_by(desc(DriverPackRating.created_at))\
            .limit(10).all()
        
        pack_data = pack.to_dict()
        pack_data['setups'] = [setup.to_dict() for setup in pack_setups]
        pack_data['recent_ratings'] = [rating.to_dict() for rating in recent_ratings]
        
        return jsonify({
            'success': True,
            'driver_pack': pack_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs/<int:pack_id>/subscribe', methods=['POST'])
def subscribe_to_driver_pack(pack_id):
    """Subscribe to a driver pack"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        subscription_type = data.get('subscription_type', 'monthly')  # monthly or yearly
        payment_method = data.get('payment_method')
        payment_id = data.get('payment_id')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'Missing user_id'
            }), 400
        
        # Verify pack exists
        pack = DriverPack.query.get_or_404(pack_id)
        user = User.query.get_or_404(user_id)
        
        # Check if user already has an active subscription
        existing_subscription = DriverPackSubscription.query.filter_by(
            user_id=user_id,
            driver_pack_id=pack_id,
            status='active'
        ).first()
        
        if existing_subscription:
            return jsonify({
                'success': False,
                'error': 'User already has an active subscription to this pack'
            }), 400
        
        # Calculate end date and amount
        if subscription_type == 'yearly':
            end_date = datetime.utcnow() + timedelta(days=365)
            amount = pack.yearly_price if pack.yearly_price else pack.monthly_price * 12
        else:
            end_date = datetime.utcnow() + timedelta(days=30)
            amount = pack.monthly_price
        
        subscription = DriverPackSubscription(
            user_id=user_id,
            driver_pack_id=pack_id,
            subscription_type=subscription_type,
            end_date=end_date,
            payment_method=payment_method,
            payment_id=payment_id,
            amount_paid=amount
        )
        
        db.session.add(subscription)
        
        # Update pack subscriber count
        pack.subscriber_count += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'subscription': subscription.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs/<int:pack_id>/unsubscribe', methods=['POST'])
def unsubscribe_from_driver_pack(pack_id):
    """Cancel subscription to a driver pack"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'Missing user_id'
            }), 400
        
        subscription = DriverPackSubscription.query.filter_by(
            user_id=user_id,
            driver_pack_id=pack_id,
            status='active'
        ).first()
        
        if not subscription:
            return jsonify({
                'success': False,
                'error': 'No active subscription found'
            }), 404
        
        subscription.status = 'cancelled'
        subscription.cancelled_at = datetime.utcnow()
        subscription.auto_renew = False
        
        # Update pack subscriber count
        pack = DriverPack.query.get(pack_id)
        if pack:
            pack.subscriber_count = max(0, pack.subscriber_count - 1)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Subscription cancelled successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/users/<int:user_id>/subscriptions', methods=['GET'])
def get_user_subscriptions(user_id):
    """Get user's driver pack subscriptions"""
    try:
        user = User.query.get_or_404(user_id)
        
        status_filter = request.args.get('status', 'active')
        
        query = DriverPackSubscription.query.filter_by(user_id=user_id)
        
        if status_filter != 'all':
            query = query.filter_by(status=status_filter)
        
        subscriptions = query.order_by(desc(DriverPackSubscription.created_at)).all()
        
        # Include driver pack info
        subscription_data = []
        for sub in subscriptions:
            sub_dict = sub.to_dict()
            sub_dict['driver_pack'] = sub.driver_pack.to_dict() if sub.driver_pack else None
            subscription_data.append(sub_dict)
        
        return jsonify({
            'success': True,
            'subscriptions': subscription_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs/<int:pack_id>/rate', methods=['POST'])
def rate_driver_pack(pack_id):
    """Rate a driver pack"""
    try:
        data = request.get_json()
        
        required_fields = ['user_id', 'rating']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        user_id = data['user_id']
        rating_value = data['rating']
        comment = data.get('comment')
        
        # Validate rating
        if not isinstance(rating_value, int) or rating_value < 1 or rating_value > 5:
            return jsonify({
                'success': False,
                'error': 'Rating must be an integer between 1 and 5'
            }), 400
        
        # Verify pack and user exist
        pack = DriverPack.query.get_or_404(pack_id)
        user = User.query.get_or_404(user_id)
        
        # Check if user has an active subscription
        subscription = DriverPackSubscription.query.filter_by(
            user_id=user_id,
            driver_pack_id=pack_id,
            status='active'
        ).first()
        
        if not subscription:
            return jsonify({
                'success': False,
                'error': 'You must be subscribed to rate this pack'
            }), 403
        
        # Check if user already rated this pack
        existing_rating = DriverPackRating.query.filter_by(
            driver_pack_id=pack_id,
            user_id=user_id
        ).first()
        
        if existing_rating:
            # Update existing rating
            old_rating = existing_rating.rating
            existing_rating.rating = rating_value
            existing_rating.comment = comment
            existing_rating.updated_at = datetime.utcnow()
            
            # Update pack average rating
            pack.rating_average = ((pack.rating_average * pack.rating_count) - old_rating + rating_value) / pack.rating_count
        else:
            # Create new rating
            new_rating = DriverPackRating(
                driver_pack_id=pack_id,
                user_id=user_id,
                rating=rating_value,
                comment=comment
            )
            
            db.session.add(new_rating)
            
            # Update pack average rating
            pack.rating_count += 1
            pack.rating_average = ((pack.rating_average * (pack.rating_count - 1)) + rating_value) / pack.rating_count
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Rating submitted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/driver-packs/<int:pack_id>/setups', methods=['POST'])
def add_setup_to_pack(pack_id):
    """Add a setup to a driver pack"""
    try:
        data = request.get_json()
        
        required_fields = ['setup_id']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify pack and setup exist
        pack = DriverPack.query.get_or_404(pack_id)
        setup = Setup.query.get_or_404(data['setup_id'])
        
        # Check if setup is already in the pack
        existing = DriverPackSetup.query.filter_by(
            driver_pack_id=pack_id,
            setup_id=data['setup_id']
        ).first()
        
        if existing:
            return jsonify({
                'success': False,
                'error': 'Setup already exists in this pack'
            }), 400
        
        pack_setup = DriverPackSetup(
            driver_pack_id=pack_id,
            setup_id=data['setup_id'],
            driver_notes=data.get('driver_notes'),
            performance_data=data.get('performance_data'),
            video_url=data.get('video_url'),
            is_featured=data.get('is_featured', False)
        )
        
        db.session.add(pack_setup)
        
        # Update pack total setups count
        pack.total_setups += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'pack_setup': pack_setup.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Premium Features Routes
@driver_packs_bp.route('/premium-features', methods=['GET'])
def get_premium_features():
    """Get all available premium features"""
    try:
        features = PremiumFeature.query.filter_by(is_active=True).all()
        
        return jsonify({
            'success': True,
            'premium_features': [feature.to_dict() for feature in features]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@driver_packs_bp.route('/premium-features', methods=['POST'])
def create_premium_feature():
    """Create a new premium feature"""
    try:
        data = request.get_json()
        
        required_fields = ['name', 'feature_key']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        feature = PremiumFeature(
            name=data['name'],
            description=data.get('description'),
            feature_key=data['feature_key'],
            monthly_price=data.get('monthly_price'),
            yearly_price=data.get('yearly_price'),
            is_standalone=data.get('is_standalone', True)
        )
        
        db.session.add(feature)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'premium_feature': feature.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Analytics Routes
@driver_packs_bp.route('/driver-packs/analytics', methods=['GET'])
def get_driver_packs_analytics():
    """Get analytics data for driver packs"""
    try:
        # Total revenue by month
        monthly_revenue = db.session.query(
            db.func.strftime('%Y-%m', DriverPackSubscription.created_at).label('month'),
            db.func.sum(DriverPackSubscription.amount_paid).label('revenue')
        ).filter(
            DriverPackSubscription.status.in_(['active', 'cancelled'])
        ).group_by('month').order_by('month').all()
        
        # Most popular packs
        popular_packs = db.session.query(
            DriverPack.pack_name,
            DriverPack.driver_name,
            DriverPack.subscriber_count,
            DriverPack.rating_average
        ).order_by(desc(DriverPack.subscriber_count)).limit(10).all()
        
        # Subscription stats
        total_subscriptions = DriverPackSubscription.query.filter_by(status='active').count()
        total_revenue = db.session.query(db.func.sum(DriverPackSubscription.amount_paid))\
            .filter(DriverPackSubscription.status.in_(['active', 'cancelled'])).scalar() or 0
        
        return jsonify({
            'success': True,
            'analytics': {
                'monthly_revenue': [
                    {'month': month, 'revenue': float(revenue)}
                    for month, revenue in monthly_revenue
                ],
                'popular_packs': [
                    {
                        'pack_name': pack_name,
                        'driver_name': driver_name,
                        'subscriber_count': subscriber_count,
                        'rating_average': float(rating_average) if rating_average else 0
                    }
                    for pack_name, driver_name, subscriber_count, rating_average in popular_packs
                ],
                'total_subscriptions': total_subscriptions,
                'total_revenue': float(total_revenue)
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

