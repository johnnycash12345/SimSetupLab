from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.community import Forum, ForumTopic, ForumPost, UserFollow, Notification, UserAchievement
from sqlalchemy import desc, and_, or_

community_bp = Blueprint('community', __name__)

# Forum Routes
@community_bp.route('/forums', methods=['GET'])
def get_forums():
    """Get all active forums"""
    try:
        game_id = request.args.get('game_id', type=int)
        category = request.args.get('category')
        
        query = Forum.query.filter_by(is_active=True)
        
        if game_id:
            query = query.filter_by(game_id=game_id)
        if category:
            query = query.filter_by(category=category)
        
        forums = query.all()
        return jsonify({
            'success': True,
            'forums': [forum.to_dict() for forum in forums]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/forums', methods=['POST'])
def create_forum():
    """Create a new forum"""
    try:
        data = request.get_json()
        
        required_fields = ['name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        forum = Forum(
            name=data['name'],
            description=data.get('description'),
            category=data.get('category'),
            game_id=data.get('game_id')
        )
        
        db.session.add(forum)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'forum': forum.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/forums/<int:forum_id>/topics', methods=['GET'])
def get_forum_topics(forum_id):
    """Get topics for a specific forum"""
    try:
        forum = Forum.query.get_or_404(forum_id)
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Order by pinned first, then by last reply
        topics = ForumTopic.query.filter_by(forum_id=forum_id)\
            .order_by(desc(ForumTopic.is_pinned), desc(ForumTopic.last_reply_at))\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'topics': [topic.to_dict() for topic in topics.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': topics.total,
                'pages': topics.pages,
                'has_next': topics.has_next,
                'has_prev': topics.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/topics', methods=['POST'])
def create_topic():
    """Create a new forum topic"""
    try:
        data = request.get_json()
        
        required_fields = ['forum_id', 'user_id', 'title', 'content']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify forum and user exist
        forum = Forum.query.get_or_404(data['forum_id'])
        user = User.query.get_or_404(data['user_id'])
        
        topic = ForumTopic(
            forum_id=data['forum_id'],
            user_id=data['user_id'],
            title=data['title'],
            content=data['content']
        )
        
        db.session.add(topic)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'topic': topic.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/topics/<int:topic_id>', methods=['GET'])
def get_topic(topic_id):
    """Get a specific topic with its posts"""
    try:
        topic = ForumTopic.query.get_or_404(topic_id)
        
        # Increment view count
        topic.view_count += 1
        db.session.commit()
        
        # Get posts
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        posts = ForumPost.query.filter_by(topic_id=topic_id, is_deleted=False)\
            .order_by(ForumPost.created_at)\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        # Include related data
        topic_data = topic.to_dict()
        topic_data['user'] = topic.user.to_dict() if topic.user else None
        topic_data['forum'] = topic.forum.to_dict() if topic.forum else None
        
        return jsonify({
            'success': True,
            'topic': topic_data,
            'posts': [post.to_dict() for post in posts.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': posts.total,
                'pages': posts.pages,
                'has_next': posts.has_next,
                'has_prev': posts.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/posts', methods=['POST'])
def create_post():
    """Create a new forum post"""
    try:
        data = request.get_json()
        
        required_fields = ['topic_id', 'user_id', 'content']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify topic and user exist
        topic = ForumTopic.query.get_or_404(data['topic_id'])
        user = User.query.get_or_404(data['user_id'])
        
        # Check if topic is locked
        if topic.is_locked:
            return jsonify({
                'success': False,
                'error': 'Topic is locked'
            }), 403
        
        post = ForumPost(
            topic_id=data['topic_id'],
            user_id=data['user_id'],
            content=data['content'],
            parent_post_id=data.get('parent_post_id')
        )
        
        db.session.add(post)
        
        # Update topic reply count and last reply info
        topic.reply_count += 1
        topic.last_reply_at = post.created_at
        topic.last_reply_user_id = data['user_id']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'post': post.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# User Follow System
@community_bp.route('/users/<int:user_id>/follow', methods=['POST'])
def follow_user(user_id):
    """Follow a user"""
    try:
        data = request.get_json()
        follower_id = data.get('follower_id')
        
        if not follower_id:
            return jsonify({
                'success': False,
                'error': 'Missing follower_id'
            }), 400
        
        if follower_id == user_id:
            return jsonify({
                'success': False,
                'error': 'Cannot follow yourself'
            }), 400
        
        # Check if already following
        existing_follow = UserFollow.query.filter_by(
            follower_id=follower_id,
            following_id=user_id
        ).first()
        
        if existing_follow:
            return jsonify({
                'success': False,
                'error': 'Already following this user'
            }), 400
        
        # Verify users exist
        follower = User.query.get_or_404(follower_id)
        following = User.query.get_or_404(user_id)
        
        follow = UserFollow(
            follower_id=follower_id,
            following_id=user_id
        )
        
        db.session.add(follow)
        
        # Create notification
        notification = Notification(
            user_id=user_id,
            type='new_follower',
            title='Novo Seguidor',
            message=f'{follower.username} começou a seguir você',
            related_id=follower_id,
            related_type='user'
        )
        
        db.session.add(notification)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User followed successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/users/<int:user_id>/unfollow', methods=['POST'])
def unfollow_user(user_id):
    """Unfollow a user"""
    try:
        data = request.get_json()
        follower_id = data.get('follower_id')
        
        if not follower_id:
            return jsonify({
                'success': False,
                'error': 'Missing follower_id'
            }), 400
        
        follow = UserFollow.query.filter_by(
            follower_id=follower_id,
            following_id=user_id
        ).first()
        
        if not follow:
            return jsonify({
                'success': False,
                'error': 'Not following this user'
            }), 400
        
        db.session.delete(follow)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User unfollowed successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/users/<int:user_id>/followers', methods=['GET'])
def get_user_followers(user_id):
    """Get user's followers"""
    try:
        user = User.query.get_or_404(user_id)
        
        followers = db.session.query(User, UserFollow)\
            .join(UserFollow, User.id == UserFollow.follower_id)\
            .filter(UserFollow.following_id == user_id)\
            .all()
        
        return jsonify({
            'success': True,
            'followers': [follower.to_dict() for follower, _ in followers]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/users/<int:user_id>/following', methods=['GET'])
def get_user_following(user_id):
    """Get users that this user is following"""
    try:
        user = User.query.get_or_404(user_id)
        
        following = db.session.query(User, UserFollow)\
            .join(UserFollow, User.id == UserFollow.following_id)\
            .filter(UserFollow.follower_id == user_id)\
            .all()
        
        return jsonify({
            'success': True,
            'following': [following_user.to_dict() for following_user, _ in following]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Notifications
@community_bp.route('/users/<int:user_id>/notifications', methods=['GET'])
def get_user_notifications(user_id):
    """Get user's notifications"""
    try:
        user = User.query.get_or_404(user_id)
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        unread_only = request.args.get('unread_only', type=bool, default=False)
        
        query = Notification.query.filter_by(user_id=user_id)
        
        if unread_only:
            query = query.filter_by(is_read=False)
        
        notifications = query.order_by(desc(Notification.created_at))\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'notifications': [notification.to_dict() for notification in notifications.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': notifications.total,
                'pages': notifications.pages,
                'has_next': notifications.has_next,
                'has_prev': notifications.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/notifications/<int:notification_id>/read', methods=['POST'])
def mark_notification_read(notification_id):
    """Mark a notification as read"""
    try:
        notification = Notification.query.get_or_404(notification_id)
        notification.is_read = True
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notification marked as read'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Achievements
@community_bp.route('/users/<int:user_id>/achievements', methods=['GET'])
def get_user_achievements(user_id):
    """Get user's achievements"""
    try:
        user = User.query.get_or_404(user_id)
        achievements = UserAchievement.query.filter_by(user_id=user_id)\
            .order_by(desc(UserAchievement.earned_at)).all()
        
        return jsonify({
            'success': True,
            'achievements': [achievement.to_dict() for achievement in achievements]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@community_bp.route('/achievements', methods=['POST'])
def award_achievement():
    """Award an achievement to a user"""
    try:
        data = request.get_json()
        
        required_fields = ['user_id', 'achievement_type', 'achievement_name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Check if user already has this achievement
        existing = UserAchievement.query.filter_by(
            user_id=data['user_id'],
            achievement_type=data['achievement_type']
        ).first()
        
        if existing:
            return jsonify({
                'success': False,
                'error': 'User already has this achievement'
            }), 400
        
        user = User.query.get_or_404(data['user_id'])
        
        achievement = UserAchievement(
            user_id=data['user_id'],
            achievement_type=data['achievement_type'],
            achievement_name=data['achievement_name'],
            description=data.get('description')
        )
        
        db.session.add(achievement)
        
        # Create notification
        notification = Notification(
            user_id=data['user_id'],
            type='new_achievement',
            title='Nova Conquista!',
            message=f'Você desbloqueou: {data["achievement_name"]}',
            related_id=achievement.id,
            related_type='achievement'
        )
        
        db.session.add(notification)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'achievement': achievement.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

