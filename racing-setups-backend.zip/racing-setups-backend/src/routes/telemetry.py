from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.telemetry import TelemetrySession, LapTime
from src.models.setup import Setup
from src.models.car import Car
from src.models.track import Track
from sqlalchemy import desc, and_, func

telemetry_bp = Blueprint('telemetry', __name__)

@telemetry_bp.route('/telemetry/sessions', methods=['GET'])
def get_telemetry_sessions():
    """Get telemetry sessions with optional filtering"""
    try:
        # Get query parameters
        user_id = request.args.get('user_id', type=int)
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        setup_id = request.args.get('setup_id', type=int)
        session_type = request.args.get('session_type')
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = TelemetrySession.query
        
        if user_id:
            query = query.filter_by(user_id=user_id)
        if car_id:
            query = query.filter_by(car_id=car_id)
        if track_id:
            query = query.filter_by(track_id=track_id)
        if setup_id:
            query = query.filter_by(setup_id=setup_id)
        if session_type:
            query = query.filter_by(session_type=session_type)
        
        # Order by creation date (newest first)
        query = query.order_by(desc(TelemetrySession.created_at))
        
        # Paginate
        sessions = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'sessions': [session.to_dict() for session in sessions.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': sessions.total,
                'pages': sessions.pages,
                'has_next': sessions.has_next,
                'has_prev': sessions.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/sessions', methods=['POST'])
def create_telemetry_session():
    """Create a new telemetry session"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['user_id', 'car_id', 'track_id']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify related entities exist
        user = User.query.get_or_404(data['user_id'])
        car = Car.query.get_or_404(data['car_id'])
        track = Track.query.get_or_404(data['track_id'])
        
        if data.get('setup_id'):
            setup = Setup.query.get_or_404(data['setup_id'])
        
        session = TelemetrySession(
            user_id=data['user_id'],
            setup_id=data.get('setup_id'),
            car_id=data['car_id'],
            track_id=data['track_id'],
            session_name=data.get('session_name'),
            session_type=data.get('session_type'),
            weather_condition=data.get('weather_condition'),
            track_temperature=data.get('track_temperature'),
            air_temperature=data.get('air_temperature'),
            session_duration=data.get('session_duration'),
            total_laps=data.get('total_laps'),
            best_lap_time=data.get('best_lap_time'),
            average_lap_time=data.get('average_lap_time'),
            fuel_used=data.get('fuel_used'),
            tire_compound=data.get('tire_compound'),
            telemetry_file_url=data.get('telemetry_file_url')
        )
        
        db.session.add(session)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session': session.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/sessions/<int:session_id>', methods=['GET'])
def get_telemetry_session(session_id):
    """Get a specific telemetry session"""
    try:
        session = TelemetrySession.query.get_or_404(session_id)
        
        # Include related data
        session_data = session.to_dict()
        session_data['user'] = session.user.to_dict() if session.user else None
        session_data['car'] = session.car.to_dict() if session.car else None
        session_data['track'] = session.track.to_dict() if session.track else None
        session_data['setup'] = session.setup.to_dict() if session.setup else None
        
        return jsonify({
            'success': True,
            'session': session_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/lap-times', methods=['GET'])
def get_lap_times():
    """Get lap times with optional filtering"""
    try:
        # Get query parameters
        user_id = request.args.get('user_id', type=int)
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        setup_id = request.args.get('setup_id', type=int)
        session_id = request.args.get('session_id', type=int)
        is_valid = request.args.get('is_valid', type=bool, default=True)
        sort_by = request.args.get('sort_by', 'lap_time')  # lap_time, created_at
        order = request.args.get('order', 'asc')  # asc, desc
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        # Build query
        query = LapTime.query.filter_by(is_valid=is_valid)
        
        if user_id:
            query = query.filter_by(user_id=user_id)
        if car_id:
            query = query.filter_by(car_id=car_id)
        if track_id:
            query = query.filter_by(track_id=track_id)
        if setup_id:
            query = query.filter_by(setup_id=setup_id)
        if session_id:
            query = query.filter_by(telemetry_session_id=session_id)
        
        # Apply sorting
        if sort_by == 'lap_time':
            if order == 'desc':
                query = query.order_by(desc(LapTime.lap_time))
            else:
                query = query.order_by(LapTime.lap_time)
        else:  # created_at
            if order == 'desc':
                query = query.order_by(desc(LapTime.created_at))
            else:
                query = query.order_by(LapTime.created_at)
        
        # Paginate
        lap_times = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'lap_times': [lap_time.to_dict() for lap_time in lap_times.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': lap_times.total,
                'pages': lap_times.pages,
                'has_next': lap_times.has_next,
                'has_prev': lap_times.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/lap-times', methods=['POST'])
def create_lap_time():
    """Create a new lap time"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['user_id', 'car_id', 'track_id', 'lap_time']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify related entities exist
        user = User.query.get_or_404(data['user_id'])
        car = Car.query.get_or_404(data['car_id'])
        track = Track.query.get_or_404(data['track_id'])
        
        if data.get('setup_id'):
            setup = Setup.query.get_or_404(data['setup_id'])
        if data.get('telemetry_session_id'):
            session = TelemetrySession.query.get_or_404(data['telemetry_session_id'])
        
        lap_time = LapTime(
            telemetry_session_id=data.get('telemetry_session_id'),
            user_id=data['user_id'],
            setup_id=data.get('setup_id'),
            car_id=data['car_id'],
            track_id=data['track_id'],
            lap_number=data.get('lap_number'),
            lap_time=data['lap_time'],
            sector_1_time=data.get('sector_1_time'),
            sector_2_time=data.get('sector_2_time'),
            sector_3_time=data.get('sector_3_time'),
            top_speed=data.get('top_speed'),
            average_speed=data.get('average_speed'),
            fuel_remaining=data.get('fuel_remaining'),
            tire_wear_fl=data.get('tire_wear_fl'),
            tire_wear_fr=data.get('tire_wear_fr'),
            tire_wear_rl=data.get('tire_wear_rl'),
            tire_wear_rr=data.get('tire_wear_rr'),
            is_valid=data.get('is_valid', True),
            weather_condition=data.get('weather_condition'),
            track_temperature=data.get('track_temperature')
        )
        
        db.session.add(lap_time)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'lap_time': lap_time.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/leaderboard', methods=['GET'])
def get_leaderboard():
    """Get leaderboard for specific car/track combination"""
    try:
        # Get query parameters
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        weather_condition = request.args.get('weather_condition')
        limit = request.args.get('limit', 10, type=int)
        
        if not car_id or not track_id:
            return jsonify({
                'success': False,
                'error': 'car_id and track_id are required'
            }), 400
        
        # Build query for best lap times
        query = db.session.query(
            LapTime.user_id,
            func.min(LapTime.lap_time).label('best_time'),
            LapTime.setup_id,
            User.username
        ).join(User).filter(
            LapTime.car_id == car_id,
            LapTime.track_id == track_id,
            LapTime.is_valid == True
        )
        
        if weather_condition:
            query = query.filter(LapTime.weather_condition == weather_condition)
        
        # Group by user and order by best time
        leaderboard = query.group_by(
            LapTime.user_id, 
            LapTime.setup_id, 
            User.username
        ).order_by('best_time').limit(limit).all()
        
        # Format results
        results = []
        for i, entry in enumerate(leaderboard, 1):
            results.append({
                'position': i,
                'user_id': entry.user_id,
                'username': entry.username,
                'lap_time': float(entry.best_time),
                'setup_id': entry.setup_id
            })
        
        return jsonify({
            'success': True,
            'leaderboard': results,
            'car_id': car_id,
            'track_id': track_id,
            'weather_condition': weather_condition
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@telemetry_bp.route('/telemetry/stats', methods=['GET'])
def get_telemetry_stats():
    """Get telemetry statistics"""
    try:
        user_id = request.args.get('user_id', type=int)
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        
        # Base query
        query = LapTime.query.filter_by(is_valid=True)
        
        if user_id:
            query = query.filter_by(user_id=user_id)
        if car_id:
            query = query.filter_by(car_id=car_id)
        if track_id:
            query = query.filter_by(track_id=track_id)
        
        # Calculate statistics
        lap_times = query.all()
        
        if not lap_times:
            return jsonify({
                'success': True,
                'stats': {
                    'total_laps': 0,
                    'best_time': None,
                    'average_time': None,
                    'worst_time': None
                }
            }), 200
        
        times = [float(lt.lap_time) for lt in lap_times]
        
        stats = {
            'total_laps': len(times),
            'best_time': min(times),
            'average_time': sum(times) / len(times),
            'worst_time': max(times)
        }
        
        return jsonify({
            'success': True,
            'stats': stats
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

