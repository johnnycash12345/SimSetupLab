from flask import Blueprint, request, jsonify
from src.models.user import db
from src.models.game import Game
from src.models.track import Track
from src.models.car import Car

games_bp = Blueprint('games', __name__)

@games_bp.route('/games', methods=['GET'])
def get_games():
    """Get all active games"""
    try:
        games = Game.query.filter_by(is_active=True).all()
        return jsonify({
            'success': True,
            'games': [game.to_dict() for game in games]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/games/<int:game_id>', methods=['GET'])
def get_game(game_id):
    """Get a specific game by ID"""
    try:
        game = Game.query.get_or_404(game_id)
        return jsonify({
            'success': True,
            'game': game.to_dict()
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/games', methods=['POST'])
def create_game():
    """Create a new game"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'display_name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        game = Game(
            name=data['name'],
            display_name=data['display_name'],
            developer=data.get('developer'),
            api_endpoint=data.get('api_endpoint'),
            telemetry_support=data.get('telemetry_support', False),
            icon_url=data.get('icon_url'),
            description=data.get('description')
        )
        
        db.session.add(game)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'game': game.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/games/<int:game_id>/tracks', methods=['GET'])
def get_game_tracks(game_id):
    """Get all tracks for a specific game"""
    try:
        game = Game.query.get_or_404(game_id)
        tracks = Track.query.filter_by(game_id=game_id, is_active=True).all()
        return jsonify({
            'success': True,
            'tracks': [track.to_dict() for track in tracks]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/games/<int:game_id>/cars', methods=['GET'])
def get_game_cars(game_id):
    """Get all cars for a specific game"""
    try:
        game = Game.query.get_or_404(game_id)
        cars = Car.query.filter_by(game_id=game_id, is_active=True).all()
        return jsonify({
            'success': True,
            'cars': [car.to_dict() for car in cars]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/tracks', methods=['POST'])
def create_track():
    """Create a new track"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['game_id', 'name', 'display_name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify game exists
        game = Game.query.get_or_404(data['game_id'])
        
        track = Track(
            game_id=data['game_id'],
            name=data['name'],
            display_name=data['display_name'],
            country=data.get('country'),
            length_meters=data.get('length_meters'),
            turns_count=data.get('turns_count'),
            track_type=data.get('track_type'),
            weather_conditions=data.get('weather_conditions', [])
        )
        
        db.session.add(track)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'track': track.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@games_bp.route('/cars', methods=['POST'])
def create_car():
    """Create a new car"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['game_id', 'name', 'display_name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify game exists
        game = Game.query.get_or_404(data['game_id'])
        
        car = Car(
            game_id=data['game_id'],
            name=data['name'],
            display_name=data['display_name'],
            manufacturer=data.get('manufacturer'),
            category=data.get('category'),
            year=data.get('year'),
            power_hp=data.get('power_hp'),
            weight_kg=data.get('weight_kg'),
            drivetrain=data.get('drivetrain'),
            image_url=data.get('image_url')
        )
        
        db.session.add(car)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'car': car.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

