from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.competitions import Competition, CompetitionParticipant, CompetitionResult, Sponsor, CompetitionTemplate, Prize
from src.models.setup import Setup
from src.models.game import Game
from src.models.car import Car
from src.models.track import Track
from sqlalchemy import desc, and_, or_, func
from datetime import datetime, timedelta

competitions_bp = Blueprint('competitions', __name__)

# Competition Routes
@competitions_bp.route('/competitions', methods=['GET'])
def get_competitions():
    """Get competitions with filters"""
    try:
        # Filtros
        status = request.args.get('status')  # upcoming, registration_open, active, finished
        competition_type = request.args.get('type')
        game_id = request.args.get('game_id', type=int)
        skill_level = request.args.get('skill_level')
        
        # Paginação
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Ordenação
        sort_by = request.args.get('sort_by', 'created_at')  # created_at, prize_pool, participants
        
        query = Competition.query
        
        # Aplicar filtros
        if status:
            query = query.filter_by(status=status)
        if competition_type:
            query = query.filter_by(competition_type=competition_type)
        if game_id:
            query = query.filter_by(game_id=game_id)
        if skill_level:
            query = query.filter_by(min_skill_level=skill_level)
        
        # Aplicar ordenação
        if sort_by == 'prize_pool':
            query = query.order_by(desc(Competition.total_prize_pool))
        elif sort_by == 'participants':
            query = query.order_by(desc(Competition.participant_count))
        elif sort_by == 'ending_soon':
            query = query.filter(Competition.status.in_(['registration_open', 'active']))\
                         .order_by(Competition.competition_end.asc())
        else:
            query = query.order_by(desc(Competition.created_at))
        
        competitions = query.paginate(page=page, per_page=per_page, error_out=False)
        
        # Incluir dados relacionados
        competition_data = []
        for comp in competitions.items:
            comp_dict = comp.to_dict()
            comp_dict['game'] = comp.game.to_dict() if comp.game else None
            comp_dict['car'] = comp.car.to_dict() if comp.car else None
            comp_dict['track'] = comp.track.to_dict() if comp.track else None
            comp_dict['sponsor'] = comp.sponsor.to_dict() if comp.sponsor else None
            competition_data.append(comp_dict)
        
        return jsonify({
            'success': True,
            'competitions': competition_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': competitions.total,
                'pages': competitions.pages,
                'has_next': competitions.has_next,
                'has_prev': competitions.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/competitions', methods=['POST'])
def create_competition():
    """Create a new competition"""
    try:
        data = request.get_json()
        
        required_fields = ['title', 'competition_type', 'game_id', 'registration_start', 
                          'registration_end', 'competition_start', 'competition_end', 'created_by']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Validar datas
        reg_start = datetime.fromisoformat(data['registration_start'].replace('Z', '+00:00'))
        reg_end = datetime.fromisoformat(data['registration_end'].replace('Z', '+00:00'))
        comp_start = datetime.fromisoformat(data['competition_start'].replace('Z', '+00:00'))
        comp_end = datetime.fromisoformat(data['competition_end'].replace('Z', '+00:00'))
        
        if reg_start >= reg_end or reg_end >= comp_start or comp_start >= comp_end:
            return jsonify({
                'success': False,
                'error': 'Invalid date sequence'
            }), 400
        
        # Verificar se o jogo existe
        game = Game.query.get_or_404(data['game_id'])
        
        competition = Competition(
            title=data['title'],
            description=data.get('description'),
            banner_image_url=data.get('banner_image_url'),
            competition_type=data['competition_type'],
            game_id=data['game_id'],
            car_id=data.get('car_id'),
            track_id=data.get('track_id'),
            weather_condition=data.get('weather_condition'),
            session_type=data.get('session_type'),
            fuel_restriction=data.get('fuel_restriction'),
            tire_restriction=data.get('tire_restriction'),
            registration_start=reg_start,
            registration_end=reg_end,
            competition_start=comp_start,
            competition_end=comp_end,
            max_participants=data.get('max_participants'),
            entry_fee=data.get('entry_fee', 0),
            min_skill_level=data.get('min_skill_level'),
            total_prize_pool=data.get('total_prize_pool', 0),
            prize_distribution=data.get('prize_distribution'),
            sponsor_id=data.get('sponsor_id'),
            rules=data.get('rules'),
            setup_restrictions=data.get('setup_restrictions'),
            telemetry_required=data.get('telemetry_required', False),
            created_by=data['created_by']
        )
        
        # Determinar status inicial
        now = datetime.utcnow()
        if now < reg_start:
            competition.status = 'upcoming'
        elif now <= reg_end:
            competition.status = 'registration_open'
        elif now <= comp_end:
            competition.status = 'active'
        else:
            competition.status = 'finished'
        
        db.session.add(competition)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'competition': competition.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/competitions/<int:competition_id>', methods=['GET'])
def get_competition(competition_id):
    """Get a specific competition with participants and leaderboard"""
    try:
        competition = Competition.query.get_or_404(competition_id)
        
        # Incrementar view count
        competition.view_count += 1
        db.session.commit()
        
        # Obter participantes
        participants = CompetitionParticipant.query.filter_by(competition_id=competition_id)\
            .order_by(CompetitionParticipant.best_time.asc()).all()
        
        # Obter resultados finais se a competição terminou
        results = []
        if competition.status == 'finished':
            results = CompetitionResult.query.filter_by(competition_id=competition_id)\
                .order_by(CompetitionResult.final_position.asc()).all()
        
        comp_data = competition.to_dict()
        comp_data['game'] = competition.game.to_dict() if competition.game else None
        comp_data['car'] = competition.car.to_dict() if competition.car else None
        comp_data['track'] = competition.track.to_dict() if competition.track else None
        comp_data['sponsor'] = competition.sponsor.to_dict() if competition.sponsor else None
        comp_data['creator'] = {
            'username': competition.creator.username,
            'profile_image_url': competition.creator.profile_image_url
        } if competition.creator else None
        comp_data['participants'] = [p.to_dict() for p in participants]
        comp_data['results'] = [r.to_dict() for r in results]
        
        return jsonify({
            'success': True,
            'competition': comp_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/competitions/<int:competition_id>/join', methods=['POST'])
def join_competition(competition_id):
    """Join a competition"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        setup_id = data.get('setup_id')
        team_name = data.get('team_name')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'Missing user_id'
            }), 400
        
        # Verificar se a competição existe e está aberta para inscrições
        competition = Competition.query.get_or_404(competition_id)
        user = User.query.get_or_404(user_id)
        
        if competition.status != 'registration_open':
            return jsonify({
                'success': False,
                'error': 'Registration is not open for this competition'
            }), 400
        
        # Verificar se já está inscrito
        existing = CompetitionParticipant.query.filter_by(
            competition_id=competition_id,
            user_id=user_id
        ).first()
        
        if existing:
            return jsonify({
                'success': False,
                'error': 'User is already registered for this competition'
            }), 400
        
        # Verificar limite de participantes
        if competition.max_participants and competition.participant_count >= competition.max_participants:
            return jsonify({
                'success': False,
                'error': 'Competition is full'
            }), 400
        
        # Verificar nível de habilidade mínimo
        if competition.min_skill_level:
            skill_levels = ['beginner', 'intermediate', 'advanced', 'professional']
            user_level_index = skill_levels.index(user.skill_level) if user.skill_level in skill_levels else 0
            min_level_index = skill_levels.index(competition.min_skill_level)
            
            if user_level_index < min_level_index:
                return jsonify({
                    'success': False,
                    'error': f'Minimum skill level required: {competition.min_skill_level}'
                }), 400
        
        # Verificar setup se especificado
        if setup_id:
            setup = Setup.query.get_or_404(setup_id)
            if setup.user_id != user_id:
                return jsonify({
                    'success': False,
                    'error': 'Setup does not belong to user'
                }), 400
        
        participant = CompetitionParticipant(
            competition_id=competition_id,
            user_id=user_id,
            setup_id=setup_id,
            team_name=team_name,
            payment_status='paid' if competition.entry_fee == 0 else 'pending'
        )
        
        db.session.add(participant)
        
        # Atualizar contador de participantes
        competition.participant_count += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'participant': participant.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/competitions/<int:competition_id>/submit-time', methods=['POST'])
def submit_competition_time(competition_id):
    """Submit a lap time for a competition"""
    try:
        data = request.get_json()
        
        required_fields = ['user_id', 'lap_time']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        user_id = data['user_id']
        lap_time = data['lap_time']
        
        # Verificar se o usuário está inscrito na competição
        participant = CompetitionParticipant.query.filter_by(
            competition_id=competition_id,
            user_id=user_id,
            status='registered'
        ).first()
        
        if not participant:
            return jsonify({
                'success': False,
                'error': 'User is not registered for this competition'
            }), 404
        
        # Verificar se a competição está ativa
        competition = Competition.query.get_or_404(competition_id)
        if competition.status != 'active':
            return jsonify({
                'success': False,
                'error': 'Competition is not active'
            }), 400
        
        # Atualizar melhor tempo se for melhor
        if not participant.best_time or lap_time < participant.best_time:
            participant.best_time = lap_time
        
        participant.total_attempts += 1
        
        # Marcar telemetria como enviada se fornecida
        if data.get('telemetry_data'):
            participant.telemetry_submitted = True
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Time submitted successfully',
            'best_time': float(participant.best_time),
            'total_attempts': participant.total_attempts
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/competitions/<int:competition_id>/finalize', methods=['POST'])
def finalize_competition(competition_id):
    """Finalize a competition and generate results"""
    try:
        data = request.get_json()
        admin_user_id = data.get('admin_user_id')
        
        if not admin_user_id:
            return jsonify({
                'success': False,
                'error': 'Missing admin_user_id'
            }), 400
        
        competition = Competition.query.get_or_404(competition_id)
        
        # Verificar se a competição pode ser finalizada
        if competition.status != 'active':
            return jsonify({
                'success': False,
                'error': 'Competition is not active'
            }), 400
        
        # Obter participantes ordenados por melhor tempo
        participants = CompetitionParticipant.query.filter_by(
            competition_id=competition_id,
            status='registered'
        ).filter(CompetitionParticipant.best_time.isnot(None))\
         .order_by(CompetitionParticipant.best_time.asc()).all()
        
        # Gerar resultados
        for position, participant in enumerate(participants, 1):
            # Calcular prêmio baseado na distribuição
            prize_amount = 0
            prize_description = None
            
            if competition.prize_distribution and str(position) in competition.prize_distribution:
                prize_info = competition.prize_distribution[str(position)]
                if isinstance(prize_info, dict):
                    prize_amount = prize_info.get('amount', 0)
                    prize_description = prize_info.get('description')
                else:
                    prize_amount = prize_info
            
            result = CompetitionResult(
                competition_id=competition_id,
                participant_id=participant.id,
                final_position=position,
                final_time=participant.best_time,
                points_earned=max(0, 100 - (position - 1) * 5),  # Sistema de pontos simples
                prize_amount=prize_amount,
                prize_description=prize_description,
                verified_by=admin_user_id
            )
            
            db.session.add(result)
        
        # Atualizar status da competição
        competition.status = 'finished'
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Competition finalized successfully',
            'total_participants': len(participants)
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Sponsor Routes
@competitions_bp.route('/sponsors', methods=['GET'])
def get_sponsors():
    """Get all active sponsors"""
    try:
        sponsors = Sponsor.query.filter_by(is_active=True)\
            .order_by(desc(Sponsor.total_sponsored_amount)).all()
        
        return jsonify({
            'success': True,
            'sponsors': [sponsor.to_dict() for sponsor in sponsors]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@competitions_bp.route('/sponsors', methods=['POST'])
def create_sponsor():
    """Create a new sponsor"""
    try:
        data = request.get_json()
        
        required_fields = ['name']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        sponsor = Sponsor(
            name=data['name'],
            description=data.get('description'),
            logo_url=data.get('logo_url'),
            website_url=data.get('website_url'),
            contact_email=data.get('contact_email'),
            contact_phone=data.get('contact_phone'),
            contact_person=data.get('contact_person'),
            sponsor_tier=data.get('sponsor_tier', 'bronze')
        )
        
        db.session.add(sponsor)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'sponsor': sponsor.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Competition Templates Routes
@competitions_bp.route('/competition-templates', methods=['GET'])
def get_competition_templates():
    """Get competition templates"""
    try:
        category = request.args.get('category')
        game_id = request.args.get('game_id', type=int)
        
        query = CompetitionTemplate.query.filter_by(is_active=True)
        
        if category:
            query = query.filter_by(category=category)
        
        if game_id:
            query = query.filter(CompetitionTemplate.supported_games.contains([game_id]))
        
        templates = query.order_by(desc(CompetitionTemplate.usage_count)).all()
        
        return jsonify({
            'success': True,
            'templates': [template.to_dict() for template in templates]
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Analytics Routes
@competitions_bp.route('/competitions/analytics', methods=['GET'])
def get_competitions_analytics():
    """Get competition analytics"""
    try:
        # Competições por status
        status_stats = db.session.query(
            Competition.status,
            func.count(Competition.id).label('count')
        ).group_by(Competition.status).all()
        
        # Participação por mês
        monthly_participation = db.session.query(
            func.strftime('%Y-%m', CompetitionParticipant.registration_date).label('month'),
            func.count(CompetitionParticipant.id).label('participants')
        ).group_by('month').order_by('month').all()
        
        # Top competições por participantes
        top_competitions = db.session.query(
            Competition.title,
            Competition.participant_count,
            Competition.total_prize_pool
        ).order_by(desc(Competition.participant_count)).limit(10).all()
        
        # Prêmios distribuídos
        total_prizes = db.session.query(func.sum(CompetitionResult.prize_amount)).scalar() or 0
        
        return jsonify({
            'success': True,
            'analytics': {
                'status_distribution': [
                    {'status': status, 'count': count}
                    for status, count in status_stats
                ],
                'monthly_participation': [
                    {'month': month, 'participants': participants}
                    for month, participants in monthly_participation
                ],
                'top_competitions': [
                    {
                        'title': title,
                        'participant_count': participant_count,
                        'prize_pool': float(prize_pool) if prize_pool else 0
                    }
                    for title, participant_count, prize_pool in top_competitions
                ],
                'total_prizes_awarded': float(total_prizes)
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

