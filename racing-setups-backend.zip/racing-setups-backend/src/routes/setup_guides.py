from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.setup_guides import SetupGuide, GuideSection, SetupProblem, SetupTip, GuideFeedback, SetupWizard, WizardSession
from src.models.setup import Setup
from src.models.game import Game
from src.models.car import Car
from src.models.track import Track
from sqlalchemy import desc, and_, or_, func
from datetime import datetime

setup_guides_bp = Blueprint('setup_guides', __name__)

# Setup Guides Routes
@setup_guides_bp.route('/setup-guides', methods=['GET'])
def get_setup_guides():
    """Get setup guides with filters"""
    try:
        # Filtros
        difficulty_level = request.args.get('difficulty_level')
        guide_type = request.args.get('guide_type')
        category = request.args.get('category')
        game_id = request.args.get('game_id', type=int)
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        featured_only = request.args.get('featured_only', type=bool, default=False)
        
        # Paginação
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Ordenação
        sort_by = request.args.get('sort_by', 'created_at')  # created_at, view_count, helpful_count
        
        query = SetupGuide.query.filter_by(is_published=True)
        
        # Aplicar filtros
        if difficulty_level:
            query = query.filter_by(difficulty_level=difficulty_level)
        if guide_type:
            query = query.filter_by(guide_type=guide_type)
        if category:
            query = query.filter_by(category=category)
        if game_id:
            query = query.filter_by(game_id=game_id)
        if car_id:
            query = query.filter_by(car_id=car_id)
        if track_id:
            query = query.filter_by(track_id=track_id)
        if featured_only:
            query = query.filter_by(is_featured=True)
        
        # Aplicar ordenação
        if sort_by == 'view_count':
            query = query.order_by(desc(SetupGuide.view_count))
        elif sort_by == 'helpful_count':
            query = query.order_by(desc(SetupGuide.helpful_count))
        else:
            query = query.order_by(desc(SetupGuide.created_at))
        
        guides = query.paginate(page=page, per_page=per_page, error_out=False)
        
        # Incluir dados relacionados
        guide_data = []
        for guide in guides.items:
            guide_dict = guide.to_dict()
            guide_dict['game'] = guide.game.to_dict() if guide.game else None
            guide_dict['car'] = guide.car.to_dict() if guide.car else None
            guide_dict['track'] = guide.track.to_dict() if guide.track else None
            guide_dict['author'] = {
                'username': guide.author.username,
                'profile_image_url': guide.author.profile_image_url
            } if guide.author else None
            guide_data.append(guide_dict)
        
        return jsonify({
            'success': True,
            'guides': guide_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': guides.total,
                'pages': guides.pages,
                'has_next': guides.has_next,
                'has_prev': guides.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-guides', methods=['POST'])
def create_setup_guide():
    """Create a new setup guide"""
    try:
        data = request.get_json()
        
        required_fields = ['title', 'difficulty_level', 'guide_type', 'content', 'author_id']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verificar se o autor existe
        author = User.query.get_or_404(data['author_id'])
        
        guide = SetupGuide(
            title=data['title'],
            description=data.get('description'),
            thumbnail_url=data.get('thumbnail_url'),
            difficulty_level=data['difficulty_level'],
            guide_type=data['guide_type'],
            category=data.get('category'),
            game_id=data.get('game_id'),
            car_id=data.get('car_id'),
            track_id=data.get('track_id'),
            content=data['content'],
            video_url=data.get('video_url'),
            interactive_elements=data.get('interactive_elements'),
            example_setup_data=data.get('example_setup_data'),
            before_after_comparison=data.get('before_after_comparison'),
            estimated_read_time=data.get('estimated_read_time'),
            author_id=data['author_id']
        )
        
        db.session.add(guide)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'guide': guide.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-guides/<int:guide_id>', methods=['GET'])
def get_setup_guide(guide_id):
    """Get a specific setup guide with sections"""
    try:
        guide = SetupGuide.query.get_or_404(guide_id)
        
        # Incrementar view count
        guide.view_count += 1
        db.session.commit()
        
        # Obter seções do guia
        sections = GuideSection.query.filter_by(guide_id=guide_id)\
            .order_by(GuideSection.section_order.asc()).all()
        
        # Obter feedback recente
        recent_feedback = GuideFeedback.query.filter_by(guide_id=guide_id)\
            .order_by(desc(GuideFeedback.created_at))\
            .limit(10).all()
        
        guide_data = guide.to_dict()
        guide_data['game'] = guide.game.to_dict() if guide.game else None
        guide_data['car'] = guide.car.to_dict() if guide.car else None
        guide_data['track'] = guide.track.to_dict() if guide.track else None
        guide_data['author'] = {
            'username': guide.author.username,
            'profile_image_url': guide.author.profile_image_url,
            'bio': guide.author.bio
        } if guide.author else None
        guide_data['sections'] = [section.to_dict() for section in sections]
        guide_data['recent_feedback'] = [feedback.to_dict() for feedback in recent_feedback]
        
        return jsonify({
            'success': True,
            'guide': guide_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-guides/<int:guide_id>/feedback', methods=['POST'])
def submit_guide_feedback(guide_id):
    """Submit feedback for a guide"""
    try:
        data = request.get_json()
        
        required_fields = ['user_id']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        user_id = data['user_id']
        
        # Verificar se o guia e usuário existem
        guide = SetupGuide.query.get_or_404(guide_id)
        user = User.query.get_or_404(user_id)
        
        # Verificar se já existe feedback deste usuário
        existing_feedback = GuideFeedback.query.filter_by(
            guide_id=guide_id,
            user_id=user_id
        ).first()
        
        if existing_feedback:
            # Atualizar feedback existente
            existing_feedback.is_helpful = data.get('is_helpful')
            existing_feedback.rating = data.get('rating')
            existing_feedback.comment = data.get('comment')
            existing_feedback.suggested_improvements = data.get('suggested_improvements')
            
            feedback = existing_feedback
        else:
            # Criar novo feedback
            feedback = GuideFeedback(
                guide_id=guide_id,
                user_id=user_id,
                is_helpful=data.get('is_helpful'),
                rating=data.get('rating'),
                comment=data.get('comment'),
                suggested_improvements=data.get('suggested_improvements')
            )
            
            db.session.add(feedback)
            
            # Atualizar contador de helpful se aplicável
            if data.get('is_helpful'):
                guide.helpful_count += 1
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'feedback': feedback.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Setup Problems Routes
@setup_guides_bp.route('/setup-problems', methods=['GET'])
def get_setup_problems():
    """Get setup problems with filters"""
    try:
        game_id = request.args.get('game_id', type=int)
        car_category = request.args.get('car_category')
        track_type = request.args.get('track_type')
        difficulty = request.args.get('difficulty')
        frequency = request.args.get('frequency')
        search = request.args.get('search')
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        query = SetupProblem.query
        
        # Aplicar filtros
        if game_id:
            query = query.filter_by(game_id=game_id)
        if car_category:
            query = query.filter_by(car_category=car_category)
        if track_type:
            query = query.filter_by(track_type=track_type)
        if difficulty:
            query = query.filter_by(difficulty_to_fix=difficulty)
        if frequency:
            query = query.filter_by(frequency=frequency)
        if search:
            query = query.filter(
                or_(
                    SetupProblem.problem_title.contains(search),
                    SetupProblem.problem_description.contains(search)
                )
            )
        
        problems = query.order_by(desc(SetupProblem.helpful_count))\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'problems': [problem.to_dict() for problem in problems.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': problems.total,
                'pages': problems.pages,
                'has_next': problems.has_next,
                'has_prev': problems.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-problems', methods=['POST'])
def create_setup_problem():
    """Create a new setup problem"""
    try:
        data = request.get_json()
        
        required_fields = ['problem_title', 'problem_description', 'solutions', 'created_by']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        problem = SetupProblem(
            problem_title=data['problem_title'],
            problem_description=data['problem_description'],
            symptoms=data.get('symptoms', []),
            game_id=data.get('game_id'),
            car_category=data.get('car_category'),
            track_type=data.get('track_type'),
            solutions=data['solutions'],
            setup_adjustments=data.get('setup_adjustments'),
            difficulty_to_fix=data.get('difficulty_to_fix', 'medium'),
            frequency=data.get('frequency', 'common'),
            created_by=data['created_by']
        )
        
        db.session.add(problem)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'problem': problem.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Setup Tips Routes
@setup_guides_bp.route('/setup-tips', methods=['GET'])
def get_setup_tips():
    """Get setup tips with filters"""
    try:
        category = request.args.get('category')
        difficulty_level = request.args.get('difficulty_level')
        game_id = request.args.get('game_id', type=int)
        impact_level = request.args.get('impact_level')
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        query = SetupTip.query
        
        # Aplicar filtros
        if category:
            query = query.filter_by(category=category)
        if difficulty_level:
            query = query.filter_by(difficulty_level=difficulty_level)
        if game_id:
            query = query.filter_by(game_id=game_id)
        if impact_level:
            query = query.filter_by(impact_level=impact_level)
        
        tips = query.order_by(desc(SetupTip.like_count))\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'tips': [tip.to_dict() for tip in tips.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': tips.total,
                'pages': tips.pages,
                'has_next': tips.has_next,
                'has_prev': tips.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-tips', methods=['POST'])
def create_setup_tip():
    """Create a new setup tip"""
    try:
        data = request.get_json()
        
        required_fields = ['title', 'content', 'category', 'difficulty_level', 'created_by']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        tip = SetupTip(
            title=data['title'],
            content=data['content'],
            category=data['category'],
            difficulty_level=data['difficulty_level'],
            game_id=data.get('game_id'),
            applicable_cars=data.get('applicable_cars', []),
            applicable_tracks=data.get('applicable_tracks', []),
            impact_level=data.get('impact_level', 'medium'),
            performance_gain=data.get('performance_gain'),
            created_by=data['created_by']
        )
        
        db.session.add(tip)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'tip': tip.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-tips/<int:tip_id>/like', methods=['POST'])
def like_setup_tip(tip_id):
    """Like a setup tip"""
    try:
        tip = SetupTip.query.get_or_404(tip_id)
        tip.like_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'like_count': tip.like_count
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Setup Wizard Routes
@setup_guides_bp.route('/setup-wizards', methods=['GET'])
def get_setup_wizards():
    """Get available setup wizards"""
    try:
        game_id = request.args.get('game_id', type=int)
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        
        query = SetupWizard.query.filter_by(is_active=True)
        
        if game_id:
            query = query.filter_by(game_id=game_id)
        if car_id:
            query = query.filter(
                or_(SetupWizard.car_id == car_id, SetupWizard.car_id.is_(None))
            )
        if track_id:
            query = query.filter(
                or_(SetupWizard.track_id == track_id, SetupWizard.track_id.is_(None))
            )
        
        wizards = query.order_by(desc(SetupWizard.success_rate)).all()
        
        wizard_data = []
        for wizard in wizards:
            wizard_dict = wizard.to_dict()
            wizard_dict['game'] = wizard.game.to_dict() if wizard.game else None
            wizard_dict['car'] = wizard.car.to_dict() if wizard.car else None
            wizard_dict['track'] = wizard.track.to_dict() if wizard.track else None
            wizard_data.append(wizard_dict)
        
        return jsonify({
            'success': True,
            'wizards': wizard_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/setup-wizards/<int:wizard_id>/start', methods=['POST'])
def start_wizard_session(wizard_id):
    """Start a new wizard session"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'Missing user_id'
            }), 400
        
        wizard = SetupWizard.query.get_or_404(wizard_id)
        user = User.query.get_or_404(user_id)
        
        session = WizardSession(
            wizard_id=wizard_id,
            user_id=user_id,
            answers={}
        )
        
        db.session.add(session)
        db.session.commit()
        
        # Incrementar contador de uso
        wizard.usage_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session': session.to_dict(),
            'wizard': wizard.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/wizard-sessions/<int:session_id>/answer', methods=['POST'])
def submit_wizard_answer(session_id):
    """Submit an answer to a wizard question"""
    try:
        data = request.get_json()
        
        required_fields = ['question_id', 'answer']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        session = WizardSession.query.get_or_404(session_id)
        
        # Atualizar respostas
        if not session.answers:
            session.answers = {}
        
        session.answers[data['question_id']] = data['answer']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session': session.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/wizard-sessions/<int:session_id>/generate', methods=['POST'])
def generate_wizard_setup(session_id):
    """Generate setup based on wizard answers"""
    try:
        session = WizardSession.query.get_or_404(session_id)
        wizard = session.wizard
        
        # Lógica simples de geração de setup baseada nas respostas
        # Em uma implementação real, isso seria mais sofisticado
        generated_setup = {}
        
        # Exemplo de lógica baseada em respostas
        answers = session.answers or {}
        
        # Setup base
        base_setup = {
            'aerodynamics': {'front_wing': 5, 'rear_wing': 5},
            'suspension': {'front_height': 30, 'rear_height': 30},
            'brakes': {'pressure': 90, 'bias': 50},
            'transmission': {'differential': 80}
        }
        
        # Ajustes baseados nas respostas
        if answers.get('driving_style') == 'aggressive':
            base_setup['brakes']['pressure'] = 95
            base_setup['suspension']['front_height'] = 25
        elif answers.get('driving_style') == 'smooth':
            base_setup['brakes']['pressure'] = 85
            base_setup['suspension']['front_height'] = 35
        
        if answers.get('track_preference') == 'high_speed':
            base_setup['aerodynamics']['front_wing'] = 2
            base_setup['aerodynamics']['rear_wing'] = 3
        elif answers.get('track_preference') == 'technical':
            base_setup['aerodynamics']['front_wing'] = 8
            base_setup['aerodynamics']['rear_wing'] = 9
        
        session.generated_setup = base_setup
        session.completed_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'generated_setup': base_setup,
            'session': session.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setup_guides_bp.route('/wizard-sessions/<int:session_id>/feedback', methods=['POST'])
def submit_wizard_feedback(session_id):
    """Submit feedback for a wizard session"""
    try:
        data = request.get_json()
        
        session = WizardSession.query.get_or_404(session_id)
        wizard = session.wizard
        
        was_helpful = data.get('was_helpful')
        session.was_helpful = was_helpful
        
        # Atualizar taxa de sucesso do wizard
        if was_helpful is not None:
            total_sessions = WizardSession.query.filter_by(wizard_id=wizard.id)\
                .filter(WizardSession.was_helpful.isnot(None)).count()
            
            helpful_sessions = WizardSession.query.filter_by(wizard_id=wizard.id, was_helpful=True).count()
            
            if total_sessions > 0:
                wizard.success_rate = (helpful_sessions / total_sessions) * 100
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Feedback submitted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Analytics Routes
@setup_guides_bp.route('/setup-guides/analytics', methods=['GET'])
def get_guides_analytics():
    """Get analytics for setup guides"""
    try:
        # Guias mais visualizados
        most_viewed = db.session.query(
            SetupGuide.title,
            SetupGuide.view_count,
            SetupGuide.helpful_count
        ).order_by(desc(SetupGuide.view_count)).limit(10).all()
        
        # Distribuição por dificuldade
        difficulty_distribution = db.session.query(
            SetupGuide.difficulty_level,
            func.count(SetupGuide.id).label('count')
        ).group_by(SetupGuide.difficulty_level).all()
        
        # Problemas mais comuns
        common_problems = db.session.query(
            SetupProblem.problem_title,
            SetupProblem.view_count,
            SetupProblem.frequency
        ).order_by(desc(SetupProblem.view_count)).limit(10).all()
        
        return jsonify({
            'success': True,
            'analytics': {
                'most_viewed_guides': [
                    {
                        'title': title,
                        'view_count': view_count,
                        'helpful_count': helpful_count
                    }
                    for title, view_count, helpful_count in most_viewed
                ],
                'difficulty_distribution': [
                    {'difficulty': difficulty, 'count': count}
                    for difficulty, count in difficulty_distribution
                ],
                'common_problems': [
                    {
                        'title': title,
                        'view_count': view_count,
                        'frequency': frequency
                    }
                    for title, view_count, frequency in common_problems
                ]
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

