from flask import Blueprint, request, jsonify
from src.models.user import db, User
from src.models.setup import Setup, SetupRating
from src.models.car import Car
from src.models.track import Track
from sqlalchemy import desc, and_

setups_bp = Blueprint('setups', __name__)

@setups_bp.route('/setups', methods=['GET'])
def get_setups():
    """Get setups with optional filtering"""
    try:
        # Get query parameters
        car_id = request.args.get('car_id', type=int)
        track_id = request.args.get('track_id', type=int)
        user_id = request.args.get('user_id', type=int)
        weather_condition = request.args.get('weather_condition')
        session_type = request.args.get('session_type')
        is_public = request.args.get('is_public', type=bool, default=True)
        sort_by = request.args.get('sort_by', 'created_at')  # created_at, rating, downloads
        order = request.args.get('order', 'desc')  # asc, desc
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = Setup.query.filter_by(is_public=is_public)
        
        if car_id:
            query = query.filter_by(car_id=car_id)
        if track_id:
            query = query.filter_by(track_id=track_id)
        if user_id:
            query = query.filter_by(user_id=user_id)
        if weather_condition:
            query = query.filter_by(weather_condition=weather_condition)
        if session_type:
            query = query.filter_by(session_type=session_type)
        
        # Apply sorting
        if sort_by == 'rating':
            if order == 'desc':
                query = query.order_by(desc(Setup.rating_average))
            else:
                query = query.order_by(Setup.rating_average)
        elif sort_by == 'downloads':
            if order == 'desc':
                query = query.order_by(desc(Setup.download_count))
            else:
                query = query.order_by(Setup.download_count)
        else:  # created_at
            if order == 'desc':
                query = query.order_by(desc(Setup.created_at))
            else:
                query = query.order_by(Setup.created_at)
        
        # Paginate
        setups = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'success': True,
            'setups': [setup.to_dict() for setup in setups.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': setups.total,
                'pages': setups.pages,
                'has_next': setups.has_next,
                'has_prev': setups.has_prev
            }
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups/<int:setup_id>', methods=['GET'])
def get_setup(setup_id):
    """Get a specific setup by ID"""
    try:
        setup = Setup.query.get_or_404(setup_id)
        
        # Include related data
        setup_data = setup.to_dict()
        setup_data['user'] = setup.user.to_dict() if setup.user else None
        setup_data['car'] = setup.car.to_dict() if setup.car else None
        setup_data['track'] = setup.track.to_dict() if setup.track else None
        
        return jsonify({
            'success': True,
            'setup': setup_data
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups', methods=['POST'])
def create_setup():
    """Create a new setup"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['user_id', 'car_id', 'track_id', 'name', 'setup_data']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Verify related entities exist
        user = User.query.get_or_404(data['user_id'])
        car = Car.query.get_or_404(data['car_id'])
        track = Track.query.get_or_404(data['track_id'])
        
        setup = Setup(
            user_id=data['user_id'],
            car_id=data['car_id'],
            track_id=data['track_id'],
            name=data['name'],
            description=data.get('description'),
            setup_data=data['setup_data'],
            weather_condition=data.get('weather_condition'),
            session_type=data.get('session_type'),
            is_public=data.get('is_public', True),
            is_premium=data.get('is_premium', False),
            price=data.get('price')
        )
        
        db.session.add(setup)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'setup': setup.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups/<int:setup_id>', methods=['PUT'])
def update_setup(setup_id):
    """Update an existing setup"""
    try:
        setup = Setup.query.get_or_404(setup_id)
        data = request.get_json()
        
        # Update fields if provided
        if 'name' in data:
            setup.name = data['name']
        if 'description' in data:
            setup.description = data['description']
        if 'setup_data' in data:
            setup.setup_data = data['setup_data']
            setup.version += 1  # Increment version on setup data change
        if 'weather_condition' in data:
            setup.weather_condition = data['weather_condition']
        if 'session_type' in data:
            setup.session_type = data['session_type']
        if 'is_public' in data:
            setup.is_public = data['is_public']
        if 'is_premium' in data:
            setup.is_premium = data['is_premium']
        if 'price' in data:
            setup.price = data['price']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'setup': setup.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups/<int:setup_id>', methods=['DELETE'])
def delete_setup(setup_id):
    """Delete a setup"""
    try:
        setup = Setup.query.get_or_404(setup_id)
        db.session.delete(setup)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Setup deleted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups/<int:setup_id>/rate', methods=['POST'])
def rate_setup(setup_id):
    """Rate a setup"""
    try:
        setup = Setup.query.get_or_404(setup_id)
        data = request.get_json()
        
        # Validate required fields
        if 'user_id' not in data or 'rating' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing required fields: user_id, rating'
            }), 400
        
        if not (1 <= data['rating'] <= 5):
            return jsonify({
                'success': False,
                'error': 'Rating must be between 1 and 5'
            }), 400
        
        # Check if user already rated this setup
        existing_rating = SetupRating.query.filter_by(
            setup_id=setup_id,
            user_id=data['user_id']
        ).first()
        
        if existing_rating:
            # Update existing rating
            existing_rating.rating = data['rating']
            existing_rating.comment = data.get('comment')
        else:
            # Create new rating
            rating = SetupRating(
                setup_id=setup_id,
                user_id=data['user_id'],
                rating=data['rating'],
                comment=data.get('comment')
            )
            db.session.add(rating)
        
        db.session.commit()
        
        # Recalculate setup rating average
        ratings = SetupRating.query.filter_by(setup_id=setup_id).all()
        if ratings:
            avg_rating = sum(r.rating for r in ratings) / len(ratings)
            setup.rating_average = round(avg_rating, 2)
            setup.rating_count = len(ratings)
            db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Rating submitted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@setups_bp.route('/setups/<int:setup_id>/download', methods=['POST'])
def download_setup(setup_id):
    """Track setup download"""
    try:
        setup = Setup.query.get_or_404(setup_id)
        
        # Increment download count
        setup.download_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'setup': setup.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

