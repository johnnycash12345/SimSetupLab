#!/usr/bin/env python3
"""
Script completo para popular o banco de dados com dados de exemplo
Inclui suporte a múltiplos idiomas (PT, EN, ES)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db, User
from src.models.game import Game
from src.models.car import Car
from src.models.track import Track
from src.models.setup import Setup, SetupRating
from src.models.telemetry import TelemetrySession, LapTime
from src.models.community import Forum, ForumTopic, ForumPost, UserFollow, Notification, UserAchievement
from src.models.driver_packs import DriverPack, DriverPackSetup, DriverPackSubscription, DriverPackRating, PremiumFeature
from src.models.competitions import Competition, CompetitionParticipant, CompetitionResult, Sponsor, CompetitionTemplate, Prize
from src.models.setup_guides import SetupGuide, GuideSection, SetupProblem, SetupTip, GuideFeedback, SetupWizard, WizardSession
from datetime import datetime, timedelta
import json

def create_sample_data():
    """Cria dados de exemplo para todas as tabelas"""
    
    print("🚀 Criando dados de exemplo para RaceSetup Pro...")
    
    # 1. Criar usuários de exemplo
    print("👥 Criando usuários...")
    users_data = [
        {
            'username': 'admin',
            'email': 'admin@racesetuppro.com',
            'first_name': 'Admin',
            'last_name': 'RaceSetup',
            'country': 'BR',
            'skill_level': 'professional',
            'bio': 'Administrador da plataforma RaceSetup Pro'
        },
        {
            'username': 'gabriel_bortoleto',
            'email': 'gabriel@example.com',
            'first_name': 'Gabriel',
            'last_name': 'Bortoleto',
            'country': 'BR',
            'skill_level': 'professional',
            'bio': 'Piloto brasileiro de Fórmula 1, campeão da F2 2024'
        },
        {
            'username': 'lewis_hamilton',
            'email': 'lewis@example.com',
            'first_name': 'Lewis',
            'last_name': 'Hamilton',
            'country': 'GB',
            'skill_level': 'professional',
            'bio': '7x World Champion, Mercedes F1 Team'
        },
        {
            'username': 'fernando_alonso',
            'email': 'fernando@example.com',
            'first_name': 'Fernando',
            'last_name': 'Alonso',
            'country': 'ES',
            'skill_level': 'professional',
            'bio': '2x World Champion, Aston Martin F1 Team'
        },
        {
            'username': 'rookie_racer',
            'email': 'rookie@example.com',
            'first_name': 'João',
            'last_name': 'Silva',
            'country': 'BR',
            'skill_level': 'beginner',
            'bio': 'Iniciante no mundo do sim racing'
        }
    ]
    
    users = []
    for user_data in users_data:
        user = User(**user_data)
        user.set_password('password123')
        users.append(user)
        db.session.add(user)
    
    db.session.commit()
    print(f"✅ {len(users)} usuários criados")
    
    # 2. Criar jogos
    print("🎮 Criando jogos...")
    games_data = [
        {
            'name': 'f1_24',
            'display_name': 'F1 24',
            'developer': 'Codemasters',
            'description': 'The official Formula 1 racing game',
            'icon_url': '/images/games/f1-24.jpg',
            'telemetry_support': True,
            'is_active': True
        },
        {
            'name': 'acc',
            'display_name': 'Assetto Corsa Competizione',
            'developer': 'Kunos Simulazioni',
            'description': 'Official GT World Challenge racing simulator',
            'icon_url': '/images/games/acc.jpg',
            'telemetry_support': True,
            'is_active': True
        },
        {
            'name': 'iracing',
            'display_name': 'iRacing',
            'developer': 'iRacing.com',
            'description': 'Premier online racing simulation',
            'icon_url': '/images/games/iracing.jpg',
            'telemetry_support': True,
            'is_active': True
        },
        {
            'name': 'gt7',
            'display_name': 'Gran Turismo 7',
            'developer': 'Polyphony Digital',
            'description': 'The Real Driving Simulator',
            'icon_url': '/images/games/gt7.jpg',
            'telemetry_support': False,
            'is_active': True
        },
        {
            'name': 'forza',
            'display_name': 'Forza Motorsport',
            'developer': 'Turn 10 Studios',
            'description': 'Racing simulation with dynamic weather',
            'icon_url': '/images/games/forza.jpg',
            'telemetry_support': True,
            'is_active': True
        }
    ]
    
    games = []
    for game_data in games_data:
        game = Game(**game_data)
        games.append(game)
        db.session.add(game)
    
    db.session.commit()
    print(f"✅ {len(games)} jogos criados")
    
    # 3. Criar pistas
    print("🏁 Criando pistas...")
    tracks_data = [
        {
            'game_id': 1,  # F1 24
            'name': 'interlagos',
            'display_name': 'Interlagos',
            'country': 'BR',
            'length_meters': 4309,
            'turns_count': 15,
            'track_type': 'permanent',
            'weather_conditions': ['dry', 'wet', 'mixed']
        },
        {
            'game_id': 1,  # F1 24
            'name': 'monaco',
            'display_name': 'Monaco',
            'country': 'MC',
            'length_meters': 3337,
            'turns_count': 19,
            'track_type': 'street',
            'weather_conditions': ['dry', 'wet']
        },
        {
            'game_id': 1,  # F1 24
            'name': 'silverstone',
            'display_name': 'Silverstone',
            'country': 'GB',
            'length_meters': 5891,
            'turns_count': 18,
            'track_type': 'permanent',
            'weather_conditions': ['dry', 'wet', 'mixed']
        },
        {
            'game_id': 1,  # F1 24
            'name': 'spa',
            'display_name': 'Spa-Francorchamps',
            'country': 'BE',
            'length_meters': 7004,
            'turns_count': 20,
            'track_type': 'permanent',
            'weather_conditions': ['dry', 'wet', 'mixed']
        },
        {
            'game_id': 1,  # F1 24
            'name': 'monza',
            'display_name': 'Monza',
            'country': 'IT',
            'length_meters': 5793,
            'turns_count': 11,
            'track_type': 'permanent',
            'weather_conditions': ['dry', 'wet']
        }
    ]
    
    tracks = []
    for track_data in tracks_data:
        track = Track(**track_data)
        tracks.append(track)
        db.session.add(track)
    
    db.session.commit()
    print(f"✅ {len(tracks)} pistas criadas")
    
    # 4. Criar carros
    print("🏎️ Criando carros...")
    cars_data = [
        {
            'game_id': 1,  # F1 24
            'name': 'mercedes_w15',
            'display_name': 'Mercedes W15',
            'manufacturer': 'Mercedes-AMG',
            'category': 'Formula 1',
            'year': 2024,
            'power_hp': 1000,
            'weight_kg': 798,
            'drivetrain': 'RWD',
            'image_url': '/images/cars/mercedes-w15.jpg'
        },
        {
            'game_id': 1,  # F1 24
            'name': 'redbull_rb20',
            'display_name': 'Red Bull RB20',
            'manufacturer': 'Red Bull Racing',
            'category': 'Formula 1',
            'year': 2024,
            'power_hp': 1000,
            'weight_kg': 798,
            'drivetrain': 'RWD',
            'image_url': '/images/cars/redbull-rb20.jpg'
        },
        {
            'game_id': 1,  # F1 24
            'name': 'ferrari_sf24',
            'display_name': 'Ferrari SF-24',
            'manufacturer': 'Scuderia Ferrari',
            'category': 'Formula 1',
            'year': 2024,
            'power_hp': 1000,
            'weight_kg': 798,
            'drivetrain': 'RWD',
            'image_url': '/images/cars/ferrari-sf24.jpg'
        },
        {
            'game_id': 1,  # F1 24
            'name': 'mclaren_mcl38',
            'display_name': 'McLaren MCL38',
            'manufacturer': 'McLaren',
            'category': 'Formula 1',
            'year': 2024,
            'power_hp': 1000,
            'weight_kg': 798,
            'drivetrain': 'RWD',
            'image_url': '/images/cars/mclaren-mcl38.jpg'
        },
        {
            'game_id': 2,  # ACC
            'name': 'bmw_m4_gt3',
            'display_name': 'BMW M4 GT3',
            'manufacturer': 'BMW',
            'category': 'GT3',
            'year': 2022,
            'power_hp': 590,
            'weight_kg': 1300,
            'drivetrain': 'RWD',
            'image_url': '/images/cars/bmw-m4-gt3.jpg'
        }
    ]
    
    cars = []
    for car_data in cars_data:
        car = Car(**car_data)
        cars.append(car)
        db.session.add(car)
    
    db.session.commit()
    print(f"✅ {len(cars)} carros criados")
    
    # 5. Criar patrocinadores
    print("💰 Criando patrocinadores...")
    sponsors_data = [
        {
            'name': 'Logitech G',
            'description': 'Fabricante líder em periféricos para gaming e sim racing',
            'logo_url': '/images/sponsors/logitech-g.png',
            'website_url': 'https://www.logitechg.com',
            'contact_email': 'partnerships@logitech.com',
            'sponsor_tier': 'platinum',
            'is_active': True
        },
        {
            'name': 'Fanatec',
            'description': 'Equipamentos premium para simulação de corrida',
            'logo_url': '/images/sponsors/fanatec.png',
            'website_url': 'https://fanatec.com',
            'contact_email': 'marketing@fanatec.com',
            'sponsor_tier': 'gold',
            'is_active': True
        },
        {
            'name': 'Thrustmaster',
            'description': 'Volantes e pedais para sim racing',
            'logo_url': '/images/sponsors/thrustmaster.png',
            'website_url': 'https://www.thrustmaster.com',
            'contact_email': 'esports@thrustmaster.com',
            'sponsor_tier': 'silver',
            'is_active': True
        }
    ]
    
    sponsors = []
    for sponsor_data in sponsors_data:
        sponsor = Sponsor(**sponsor_data)
        sponsors.append(sponsor)
        db.session.add(sponsor)
    
    db.session.commit()
    print(f"✅ {len(sponsors)} patrocinadores criados")
    
    # 6. Criar pacotes de pilotos
    print("🏆 Criando pacotes de pilotos...")
    driver_packs_data = [
        {
            'driver_name': 'Gabriel Bortoleto',
            'driver_bio': 'Piloto brasileiro de Fórmula 1, campeão da F2 2024. Especialista em setups agressivos e adaptação rápida.',
            'driver_nationality': 'Brazil',
            'driver_category': 'superstar',
            'pack_name': 'Pacote Superstar Gabriel Bortoleto',
            'pack_description': 'Setups exclusivos do campeão brasileiro, com análises detalhadas e vídeos explicativos.',
            'monthly_price': 149.90,
            'yearly_price': 1499.00,
            'supported_games': [1, 2, 3],  # F1 24, ACC, iRacing
            'is_active': True
        },
        {
            'driver_name': 'Lewis Hamilton',
            'driver_bio': '7x World Champion. Master of wet weather setups and racecraft.',
            'driver_nationality': 'United Kingdom',
            'driver_category': 'legend',
            'pack_name': 'Lewis Hamilton Legend Pack',
            'pack_description': 'Championship-winning setups from the GOAT himself.',
            'monthly_price': 79.90,
            'yearly_price': 799.00,
            'supported_games': [1, 3],  # F1 24, iRacing
            'is_active': True
        },
        {
            'driver_name': 'Fernando Alonso',
            'driver_bio': '2x Campeón del Mundo. Especialista en configuraciones técnicas y circuitos complicados.',
            'driver_nationality': 'Spain',
            'driver_category': 'legend',
            'pack_name': 'Paquete Leyenda Fernando Alonso',
            'pack_description': 'Configuraciones técnicas del maestro español.',
            'monthly_price': 79.90,
            'yearly_price': 799.00,
            'supported_games': [1, 2, 3],
            'is_active': True
        },
        {
            'driver_name': 'Marco Silva',
            'driver_bio': 'Piloto profissional brasileiro de GT3, especialista em Assetto Corsa Competizione.',
            'driver_nationality': 'Brazil',
            'driver_category': 'professional',
            'pack_name': 'Pacote Professional GT3',
            'pack_description': 'Setups profissionais para GT3 com foco em consistência.',
            'monthly_price': 39.90,
            'yearly_price': 399.00,
            'supported_games': [2],  # ACC
            'is_active': True
        }
    ]
    
    driver_packs = []
    for pack_data in driver_packs_data:
        pack = DriverPack(**pack_data)
        driver_packs.append(pack)
        db.session.add(pack)
    
    db.session.commit()
    print(f"✅ {len(driver_packs)} pacotes de pilotos criados")
    
    # 7. Criar setups de exemplo
    print("⚙️ Criando setups...")
    setups_data = [
        {
            'user_id': 2,  # Gabriel Bortoleto
            'car_id': 1,   # Mercedes W15
            'track_id': 1, # Interlagos
            'name': 'Setup Agressivo Interlagos',
            'description': 'Setup otimizado para Interlagos com foco em velocidade máxima nas retas.',
            'setup_data': {
                'aerodynamics': {'front_wing': 3, 'rear_wing': 5},
                'suspension': {'front_height': 25, 'rear_height': 30},
                'brakes': {'pressure': 95, 'bias': 52},
                'transmission': {'differential': 85}
            },
            'weather_condition': 'dry',
            'session_type': 'race',
            'is_public': True,
            'rating_average': 4.8,
            'rating_count': 156,
            'download_count': 2341
        },
        {
            'user_id': 3,  # Lewis Hamilton
            'car_id': 1,   # Mercedes W15
            'track_id': 2, # Monaco
            'name': 'Monaco Wet Weather Master',
            'description': 'Perfect setup for Monaco in wet conditions. Maximum downforce and stability.',
            'setup_data': {
                'aerodynamics': {'front_wing': 10, 'rear_wing': 10},
                'suspension': {'front_height': 35, 'rear_height': 40},
                'brakes': {'pressure': 88, 'bias': 48},
                'transmission': {'differential': 75}
            },
            'weather_condition': 'wet',
            'session_type': 'race',
            'is_public': True,
            'rating_average': 4.9,
            'rating_count': 203,
            'download_count': 3456
        },
        {
            'user_id': 4,  # Fernando Alonso
            'car_id': 2,   # Red Bull RB20
            'track_id': 3, # Silverstone
            'name': 'Configuración Técnica Silverstone',
            'description': 'Setup equilibrado para Silverstone con enfoque en las curvas rápidas.',
            'setup_data': {
                'aerodynamics': {'front_wing': 6, 'rear_wing': 7},
                'suspension': {'front_height': 28, 'rear_height': 32},
                'brakes': {'pressure': 92, 'bias': 50},
                'transmission': {'differential': 80}
            },
            'weather_condition': 'dry',
            'session_type': 'qualifying',
            'is_public': True,
            'rating_average': 4.7,
            'rating_count': 89,
            'download_count': 1234
        }
    ]
    
    setups = []
    for setup_data in setups_data:
        setup = Setup(**setup_data)
        setups.append(setup)
        db.session.add(setup)
    
    db.session.commit()
    print(f"✅ {len(setups)} setups criados")
    
    # 8. Criar guias educacionais
    print("📚 Criando guias educacionais...")
    guides_data = [
        {
            'title': 'Primeiros Passos no Setup de F1',
            'description': 'Guia completo para iniciantes entenderem os conceitos básicos de setup.',
            'difficulty_level': 'beginner',
            'guide_type': 'basic_concepts',
            'category': 'general',
            'game_id': 1,  # F1 24
            'content': '''# Introdução aos Setups de F1

## O que é um Setup?

Um setup é o conjunto de configurações do seu carro que determina como ele se comporta na pista. Cada ajuste afeta diferentes aspectos da performance...

## Principais Componentes

### Aerodinâmica
- **Asa Dianteira**: Controla o downforce na frente do carro
- **Asa Traseira**: Controla o downforce na traseira

### Suspensão
- **Altura**: Afeta o centro de gravidade
- **Rigidez**: Controla como o carro reage às curvas

### Freios
- **Pressão**: Força de frenagem
- **Balanço**: Distribuição entre frente e traseira
''',
            'estimated_read_time': 10,
            'author_id': 1,  # Admin
            'is_published': True,
            'is_featured': True
        },
        {
            'title': 'Setup Guide for Beginners',
            'description': 'Complete guide for beginners to understand basic setup concepts.',
            'difficulty_level': 'beginner',
            'guide_type': 'basic_concepts',
            'category': 'general',
            'game_id': 1,  # F1 24
            'content': '''# Introduction to F1 Setups

## What is a Setup?

A setup is the collection of car configurations that determine how your car behaves on track...

## Main Components

### Aerodynamics
- **Front Wing**: Controls downforce at the front
- **Rear Wing**: Controls downforce at the rear

### Suspension
- **Height**: Affects center of gravity
- **Stiffness**: Controls how the car reacts in corners
''',
            'estimated_read_time': 10,
            'author_id': 1,  # Admin
            'is_published': True,
            'is_featured': True
        },
        {
            'title': 'Guía de Configuración para Principiantes',
            'description': 'Guía completa para principiantes para entender conceptos básicos de configuración.',
            'difficulty_level': 'beginner',
            'guide_type': 'basic_concepts',
            'category': 'general',
            'game_id': 1,  # F1 24
            'content': '''# Introducción a las Configuraciones de F1

## ¿Qué es una Configuración?

Una configuración es el conjunto de ajustes del coche que determinan cómo se comporta en pista...

## Componentes Principales

### Aerodinámica
- **Alerón Delantero**: Controla la carga aerodinámica delantera
- **Alerón Trasero**: Controla la carga aerodinámica trasera

### Suspensión
- **Altura**: Afecta el centro de gravedad
- **Rigidez**: Controla cómo reacciona el coche en curvas
''',
            'estimated_read_time': 10,
            'author_id': 1,  # Admin
            'is_published': True,
            'is_featured': True
        }
    ]
    
    guides = []
    for guide_data in guides_data:
        guide = SetupGuide(**guide_data)
        guides.append(guide)
        db.session.add(guide)
    
    db.session.commit()
    print(f"✅ {len(guides)} guias criados")
    
    # 9. Criar competições
    print("🏁 Criando competições...")
    competitions_data = [
        {
            'title': 'Desafio Interlagos 2024',
            'description': 'Competição especial no circuito brasileiro com prêmios incríveis!',
            'competition_type': 'time_trial',
            'game_id': 1,  # F1 24
            'car_id': 1,   # Mercedes W15
            'track_id': 1, # Interlagos
            'weather_condition': 'dry',
            'session_type': 'qualifying',
            'registration_start': datetime.utcnow(),
            'registration_end': datetime.utcnow() + timedelta(days=7),
            'competition_start': datetime.utcnow() + timedelta(days=7),
            'competition_end': datetime.utcnow() + timedelta(days=14),
            'max_participants': 100,
            'entry_fee': 0,
            'total_prize_pool': 5000.00,
            'prize_distribution': {
                '1': {'amount': 2000, 'description': 'Volante Logitech G Pro'},
                '2': {'amount': 1500, 'description': 'Pedais Fanatec CSL Elite'},
                '3': {'amount': 1000, 'description': 'Headset Gamer Premium'},
                '4': {'amount': 500, 'description': 'Voucher Steam R$ 500'}
            },
            'sponsor_id': 1,  # Logitech G
            'rules': 'Apenas setups padrão permitidos. Telemetria obrigatória.',
            'telemetry_required': True,
            'status': 'registration_open',
            'created_by': 1  # Admin
        },
        {
            'title': 'Monaco Grand Prix Challenge',
            'description': 'Master the streets of Monaco in this exclusive time trial.',
            'competition_type': 'time_trial',
            'game_id': 1,  # F1 24
            'track_id': 2, # Monaco
            'weather_condition': 'dry',
            'session_type': 'qualifying',
            'registration_start': datetime.utcnow() + timedelta(days=14),
            'registration_end': datetime.utcnow() + timedelta(days=21),
            'competition_start': datetime.utcnow() + timedelta(days=21),
            'competition_end': datetime.utcnow() + timedelta(days=28),
            'max_participants': 50,
            'entry_fee': 25.00,
            'total_prize_pool': 2500.00,
            'prize_distribution': {
                '1': {'amount': 1000, 'description': 'Fanatec CSL DD'},
                '2': {'amount': 750, 'description': 'Thrustmaster T300RS'},
                '3': {'amount': 500, 'description': 'Logitech G29'},
                '4': {'amount': 250, 'description': 'Gaming Chair'}
            },
            'sponsor_id': 2,  # Fanatec
            'rules': 'Open setup. Maximum 10 attempts per participant.',
            'telemetry_required': False,
            'status': 'upcoming',
            'created_by': 1  # Admin
        }
    ]
    
    competitions = []
    for comp_data in competitions_data:
        comp = Competition(**comp_data)
        competitions.append(comp)
        db.session.add(comp)
    
    db.session.commit()
    print(f"✅ {len(competitions)} competições criadas")
    
    # 10. Criar fóruns
    print("💬 Criando fóruns...")
    forums_data = [
        {
            'name': 'Discussão Geral',
            'description': 'Discussões gerais sobre sim racing e setups',
            'category': 'general',
            'is_active': True
        },
        {
            'name': 'F1 24 Setups',
            'description': 'Compartilhe e discuta setups para F1 24',
            'category': 'game_specific',
            'is_active': True
        },
        {
            'name': 'Assetto Corsa Competizione',
            'description': 'Tudo sobre ACC - setups, dicas e discussões',
            'category': 'game_specific',
            'is_active': True
        },
        {
            'name': 'Hardware e Equipamentos',
            'description': 'Discussões sobre volantes, pedais e simuladores',
            'category': 'hardware',
            'is_active': True
        },
        {
            'name': 'Competições e Eventos',
            'description': 'Organize e participe de competições',
            'category': 'competitions',
            'is_active': True
        }
    ]
    
    forums = []
    for forum_data in forums_data:
        forum = Forum(**forum_data)
        forums.append(forum)
        db.session.add(forum)
    
    db.session.commit()
    print(f"✅ {len(forums)} fóruns criados")
    
    # 11. Criar tópicos do fórum
    print("📝 Criando tópicos do fórum...")
    topics_data = [
        {
            'forum_id': 1,  # Discussão Geral
            'user_id': 5,   # Rookie Racer
            'title': 'Dicas para iniciantes no sim racing',
            'content': 'Olá pessoal! Sou novo no mundo do sim racing e gostaria de algumas dicas para começar. Que equipamentos vocês recomendam?',
            'is_pinned': False,
            'is_locked': False
        },
        {
            'forum_id': 2,  # F1 24 Setups
            'user_id': 2,   # Gabriel Bortoleto
            'title': 'Setup para Interlagos - Análise Técnica',
            'content': 'Pessoal, vou compartilhar minha análise técnica do setup que uso em Interlagos. Foco principal na saída das curvas lentas...',
            'is_pinned': True,
            'is_locked': False
        },
        {
            'forum_id': 3,  # ACC
            'user_id': 4,   # Fernando Alonso
            'title': 'GT3 Setup Philosophy at Spa',
            'content': 'Spa-Francorchamps requires a unique approach for GT3 cars. Let me share my philosophy on balancing downforce and straight-line speed...',
            'is_pinned': False,
            'is_locked': False
        }
    ]
    
    topics = []
    for topic_data in topics_data:
        topic = ForumTopic(**topic_data)
        topics.append(topic)
        db.session.add(topic)
    
    db.session.commit()
    print(f"✅ {len(topics)} tópicos criados")
    
    print("\n🎉 Dados de exemplo criados com sucesso!")
    print("📊 Resumo:")
    print(f"   👥 {len(users)} usuários")
    print(f"   🎮 {len(games)} jogos")
    print(f"   🏁 {len(tracks)} pistas")
    print(f"   🏎️ {len(cars)} carros")
    print(f"   💰 {len(sponsors)} patrocinadores")
    print(f"   🏆 {len(driver_packs)} pacotes de pilotos")
    print(f"   ⚙️ {len(setups)} setups")
    print(f"   📚 {len(guides)} guias")
    print(f"   🏁 {len(competitions)} competições")
    print(f"   💬 {len(forums)} fóruns")
    print(f"   📝 {len(topics)} tópicos")

if __name__ == '__main__':
    from src.main import app
    
    with app.app_context():
        # Limpar dados existentes
        print("🧹 Limpando dados existentes...")
        db.drop_all()
        db.create_all()
        
        # Criar dados de exemplo
        create_sample_data()
        
        print("\n✅ Script executado com sucesso!")
        print("🌐 Acesse http://localhost:5000 para ver a aplicação")

