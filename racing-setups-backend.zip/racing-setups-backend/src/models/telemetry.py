from src.models.user import db
from datetime import datetime

class TelemetrySession(db.Model):
    __tablename__ = 'telemetry_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'))
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'), nullable=False)
    session_name = db.Column(db.String(100))
    session_type = db.Column(db.String(50))  # practice, qualifying, race
    weather_condition = db.Column(db.String(50))
    track_temperature = db.Column(db.Numeric(5, 2))
    air_temperature = db.Column(db.Numeric(5, 2))
    session_duration = db.Column(db.Integer)  # in seconds
    total_laps = db.Column(db.Integer)
    best_lap_time = db.Column(db.Numeric(8, 3))  # in seconds
    average_lap_time = db.Column(db.Numeric(8, 3))
    fuel_used = db.Column(db.Numeric(6, 2))
    tire_compound = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    telemetry_file_url = db.Column(db.String(255))  # Link to stored telemetry file

    # Relationships
    user = db.relationship('User', backref='telemetry_sessions')
    lap_times = db.relationship('LapTime', backref='telemetry_session', lazy=True)

    def __repr__(self):
        return f'<TelemetrySession {self.session_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'setup_id': self.setup_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'session_name': self.session_name,
            'session_type': self.session_type,
            'weather_condition': self.weather_condition,
            'track_temperature': float(self.track_temperature) if self.track_temperature else None,
            'air_temperature': float(self.air_temperature) if self.air_temperature else None,
            'session_duration': self.session_duration,
            'total_laps': self.total_laps,
            'best_lap_time': float(self.best_lap_time) if self.best_lap_time else None,
            'average_lap_time': float(self.average_lap_time) if self.average_lap_time else None,
            'fuel_used': float(self.fuel_used) if self.fuel_used else None,
            'tire_compound': self.tire_compound,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'telemetry_file_url': self.telemetry_file_url
        }

class LapTime(db.Model):
    __tablename__ = 'lap_times'
    
    id = db.Column(db.Integer, primary_key=True)
    telemetry_session_id = db.Column(db.Integer, db.ForeignKey('telemetry_sessions.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'))
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'), nullable=False)
    lap_number = db.Column(db.Integer)
    lap_time = db.Column(db.Numeric(8, 3), nullable=False)  # in seconds
    sector_1_time = db.Column(db.Numeric(8, 3))
    sector_2_time = db.Column(db.Numeric(8, 3))
    sector_3_time = db.Column(db.Numeric(8, 3))
    top_speed = db.Column(db.Numeric(6, 2))  # km/h
    average_speed = db.Column(db.Numeric(6, 2))  # km/h
    fuel_remaining = db.Column(db.Numeric(6, 2))
    tire_wear_fl = db.Column(db.Numeric(5, 2))  # Front Left tire wear percentage
    tire_wear_fr = db.Column(db.Numeric(5, 2))  # Front Right tire wear percentage
    tire_wear_rl = db.Column(db.Numeric(5, 2))  # Rear Left tire wear percentage
    tire_wear_rr = db.Column(db.Numeric(5, 2))  # Rear Right tire wear percentage
    is_valid = db.Column(db.Boolean, default=True)  # Invalid if penalties, off-track, etc.
    weather_condition = db.Column(db.String(50))
    track_temperature = db.Column(db.Numeric(5, 2))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    user = db.relationship('User', backref='lap_times')

    def __repr__(self):
        return f'<LapTime {self.lap_time}>'

    def to_dict(self):
        return {
            'id': self.id,
            'telemetry_session_id': self.telemetry_session_id,
            'user_id': self.user_id,
            'setup_id': self.setup_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'lap_number': self.lap_number,
            'lap_time': float(self.lap_time) if self.lap_time else None,
            'sector_1_time': float(self.sector_1_time) if self.sector_1_time else None,
            'sector_2_time': float(self.sector_2_time) if self.sector_2_time else None,
            'sector_3_time': float(self.sector_3_time) if self.sector_3_time else None,
            'top_speed': float(self.top_speed) if self.top_speed else None,
            'average_speed': float(self.average_speed) if self.average_speed else None,
            'fuel_remaining': float(self.fuel_remaining) if self.fuel_remaining else None,
            'tire_wear_fl': float(self.tire_wear_fl) if self.tire_wear_fl else None,
            'tire_wear_fr': float(self.tire_wear_fr) if self.tire_wear_fr else None,
            'tire_wear_rl': float(self.tire_wear_rl) if self.tire_wear_rl else None,
            'tire_wear_rr': float(self.tire_wear_rr) if self.tire_wear_rr else None,
            'is_valid': self.is_valid,
            'weather_condition': self.weather_condition,
            'track_temperature': float(self.track_temperature) if self.track_temperature else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

