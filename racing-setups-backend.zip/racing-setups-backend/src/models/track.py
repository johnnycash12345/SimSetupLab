from src.models.user import db
from datetime import datetime

class Track(db.Model):
    __tablename__ = 'tracks'
    
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    display_name = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(2))
    length_meters = db.Column(db.Integer)
    turns_count = db.Column(db.Integer)
    track_type = db.Column(db.String(50))  # circuit, street, oval, etc.
    weather_conditions = db.Column(db.JSON)  # Array of supported weather conditions
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    setups = db.relationship('Setup', backref='track', lazy=True)
    telemetry_sessions = db.relationship('TelemetrySession', backref='track', lazy=True)
    lap_times = db.relationship('LapTime', backref='track', lazy=True)

    def __repr__(self):
        return f'<Track {self.display_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'game_id': self.game_id,
            'name': self.name,
            'display_name': self.display_name,
            'country': self.country,
            'length_meters': self.length_meters,
            'turns_count': self.turns_count,
            'track_type': self.track_type,
            'weather_conditions': self.weather_conditions,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

