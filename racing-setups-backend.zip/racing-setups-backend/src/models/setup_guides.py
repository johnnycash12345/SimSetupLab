from src.models.user import db
from datetime import datetime
from sqlalchemy import JSON, Numeric

class SetupGuide(db.Model):
    """
    Guias explicativos de setups para diferentes níveis de usuários
    """
    __tablename__ = 'setup_guides'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações básicas
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    thumbnail_url = db.Column(db.String(255))
    
    # Categorização
    difficulty_level = db.Column(db.String(20), nullable=False)  # 'beginner', 'intermediate', 'advanced'
    guide_type = db.Column(db.String(50), nullable=False)  # 'basic_concepts', 'car_specific', 'track_specific', 'problem_solving'
    category = db.Column(db.String(50))  # 'aerodynamics', 'suspension', 'brakes', 'transmission', 'general'
    
    # Contexto específico
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'))
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'))
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'))
    
    # Conteúdo
    content = db.Column(db.Text, nullable=False)  # Conteúdo principal em markdown
    video_url = db.Column(db.String(255))  # Link para vídeo explicativo
    interactive_elements = db.Column(JSON)  # Elementos interativos (sliders, comparações)
    
    # Configurações de exemplo
    example_setup_data = db.Column(JSON)  # Setup de exemplo usado no guia
    before_after_comparison = db.Column(JSON)  # Comparação antes/depois
    
    # Metadados
    estimated_read_time = db.Column(db.Integer)  # Tempo estimado de leitura em minutos
    view_count = db.Column(db.Integer, default=0)
    helpful_count = db.Column(db.Integer, default=0)  # Quantos usuários marcaram como útil
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Autoria
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    game = db.relationship('Game', backref='setup_guides')
    car = db.relationship('Car', backref='setup_guides')
    track = db.relationship('Track', backref='setup_guides')
    author = db.relationship('User', backref='authored_guides')
    sections = db.relationship('GuideSection', backref='guide', lazy=True, cascade='all, delete-orphan')
    feedbacks = db.relationship('GuideFeedback', backref='guide', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'thumbnail_url': self.thumbnail_url,
            'difficulty_level': self.difficulty_level,
            'guide_type': self.guide_type,
            'category': self.category,
            'game_id': self.game_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'content': self.content,
            'video_url': self.video_url,
            'interactive_elements': self.interactive_elements,
            'example_setup_data': self.example_setup_data,
            'before_after_comparison': self.before_after_comparison,
            'estimated_read_time': self.estimated_read_time,
            'view_count': self.view_count,
            'helpful_count': self.helpful_count,
            'is_published': self.is_published,
            'is_featured': self.is_featured,
            'author_id': self.author_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class GuideSection(db.Model):
    """
    Seções de um guia de setup (para organizar conteúdo longo)
    """
    __tablename__ = 'guide_sections'
    
    id = db.Column(db.Integer, primary_key=True)
    guide_id = db.Column(db.Integer, db.ForeignKey('setup_guides.id'), nullable=False)
    
    # Informações da seção
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    section_order = db.Column(db.Integer, nullable=False)
    
    # Tipo de conteúdo
    section_type = db.Column(db.String(50), default='text')  # 'text', 'image', 'video', 'interactive', 'comparison'
    
    # Recursos adicionais
    image_url = db.Column(db.String(255))
    video_url = db.Column(db.String(255))
    interactive_data = db.Column(JSON)  # Dados para elementos interativos
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'guide_id': self.guide_id,
            'title': self.title,
            'content': self.content,
            'section_order': self.section_order,
            'section_type': self.section_type,
            'image_url': self.image_url,
            'video_url': self.video_url,
            'interactive_data': self.interactive_data,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class SetupProblem(db.Model):
    """
    Problemas comuns de setup e suas soluções
    """
    __tablename__ = 'setup_problems'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Descrição do problema
    problem_title = db.Column(db.String(200), nullable=False)
    problem_description = db.Column(db.Text, nullable=False)
    symptoms = db.Column(JSON)  # Lista de sintomas que indicam este problema
    
    # Contexto
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'))
    car_category = db.Column(db.String(50))  # Categoria de carro afetada
    track_type = db.Column(db.String(50))  # Tipo de pista onde ocorre
    
    # Soluções
    solutions = db.Column(JSON)  # Lista de soluções possíveis
    setup_adjustments = db.Column(JSON)  # Ajustes específicos de setup
    
    # Dificuldade e frequência
    difficulty_to_fix = db.Column(db.String(20))  # 'easy', 'medium', 'hard'
    frequency = db.Column(db.String(20))  # 'common', 'occasional', 'rare'
    
    # Metadados
    view_count = db.Column(db.Integer, default=0)
    helpful_count = db.Column(db.Integer, default=0)
    
    # Autoria
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    game = db.relationship('Game', backref='setup_problems')
    creator = db.relationship('User', backref='created_problems')
    
    def to_dict(self):
        return {
            'id': self.id,
            'problem_title': self.problem_title,
            'problem_description': self.problem_description,
            'symptoms': self.symptoms,
            'game_id': self.game_id,
            'car_category': self.car_category,
            'track_type': self.track_type,
            'solutions': self.solutions,
            'setup_adjustments': self.setup_adjustments,
            'difficulty_to_fix': self.difficulty_to_fix,
            'frequency': self.frequency,
            'view_count': self.view_count,
            'helpful_count': self.helpful_count,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class SetupTip(db.Model):
    """
    Dicas rápidas de setup
    """
    __tablename__ = 'setup_tips'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Conteúdo da dica
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    
    # Categorização
    category = db.Column(db.String(50), nullable=False)  # 'aerodynamics', 'suspension', 'brakes', etc.
    difficulty_level = db.Column(db.String(20), nullable=False)
    
    # Contexto
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'))
    applicable_cars = db.Column(JSON)  # Lista de IDs de carros aplicáveis
    applicable_tracks = db.Column(JSON)  # Lista de IDs de pistas aplicáveis
    
    # Impacto
    impact_level = db.Column(db.String(20))  # 'low', 'medium', 'high'
    performance_gain = db.Column(db.String(100))  # Descrição do ganho esperado
    
    # Metadados
    view_count = db.Column(db.Integer, default=0)
    like_count = db.Column(db.Integer, default=0)
    
    # Autoria
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    game = db.relationship('Game', backref='setup_tips')
    creator = db.relationship('User', backref='created_tips')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'category': self.category,
            'difficulty_level': self.difficulty_level,
            'game_id': self.game_id,
            'applicable_cars': self.applicable_cars,
            'applicable_tracks': self.applicable_tracks,
            'impact_level': self.impact_level,
            'performance_gain': self.performance_gain,
            'view_count': self.view_count,
            'like_count': self.like_count,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class GuideFeedback(db.Model):
    """
    Feedback dos usuários sobre guias
    """
    __tablename__ = 'guide_feedback'
    
    id = db.Column(db.Integer, primary_key=True)
    guide_id = db.Column(db.Integer, db.ForeignKey('setup_guides.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Feedback
    is_helpful = db.Column(db.Boolean)  # Se o usuário achou útil
    rating = db.Column(db.Integer)  # Avaliação de 1-5
    comment = db.Column(db.Text)
    
    # Sugestões
    suggested_improvements = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    user = db.relationship('User', backref='guide_feedbacks')
    
    # Constraint para evitar múltiplos feedbacks do mesmo usuário
    __table_args__ = (
        db.UniqueConstraint('guide_id', 'user_id', name='unique_guide_feedback'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'guide_id': self.guide_id,
            'user_id': self.user_id,
            'is_helpful': self.is_helpful,
            'rating': self.rating,
            'comment': self.comment,
            'suggested_improvements': self.suggested_improvements,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'user': {
                'username': self.user.username,
                'profile_image_url': self.user.profile_image_url
            } if self.user else None
        }

class SetupWizard(db.Model):
    """
    Assistente de criação de setup para novatos
    """
    __tablename__ = 'setup_wizards'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações básicas
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    
    # Contexto
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'))
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'))
    
    # Configuração do wizard
    questions = db.Column(JSON, nullable=False)  # Perguntas do wizard
    setup_templates = db.Column(JSON, nullable=False)  # Templates de setup baseados nas respostas
    
    # Lógica de decisão
    decision_tree = db.Column(JSON)  # Árvore de decisão para gerar o setup
    
    # Metadados
    usage_count = db.Column(db.Integer, default=0)
    success_rate = db.Column(Numeric(5, 2), default=0.0)  # Taxa de sucesso baseada no feedback
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    
    # Autoria
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    game = db.relationship('Game', backref='setup_wizards')
    car = db.relationship('Car', backref='setup_wizards')
    track = db.relationship('Track', backref='setup_wizards')
    creator = db.relationship('User', backref='created_wizards')
    sessions = db.relationship('WizardSession', backref='wizard', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'game_id': self.game_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'questions': self.questions,
            'setup_templates': self.setup_templates,
            'decision_tree': self.decision_tree,
            'usage_count': self.usage_count,
            'success_rate': float(self.success_rate) if self.success_rate else 0.0,
            'is_active': self.is_active,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class WizardSession(db.Model):
    """
    Sessões de uso do wizard de setup
    """
    __tablename__ = 'wizard_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    wizard_id = db.Column(db.Integer, db.ForeignKey('setup_wizards.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Dados da sessão
    answers = db.Column(JSON, nullable=False)  # Respostas do usuário
    generated_setup = db.Column(JSON)  # Setup gerado pelo wizard
    
    # Resultado
    was_helpful = db.Column(db.Boolean)  # Feedback do usuário
    final_setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'))  # Setup final criado pelo usuário
    
    # Metadados
    session_duration = db.Column(db.Integer)  # Duração em segundos
    completed_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    user = db.relationship('User', backref='wizard_sessions')
    final_setup = db.relationship('Setup', backref='wizard_sessions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'wizard_id': self.wizard_id,
            'user_id': self.user_id,
            'answers': self.answers,
            'generated_setup': self.generated_setup,
            'was_helpful': self.was_helpful,
            'final_setup_id': self.final_setup_id,
            'session_duration': self.session_duration,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

