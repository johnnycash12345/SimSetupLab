from src.models.user import db
from datetime import datetime

class Setup(db.Model):
    __tablename__ = 'setups'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    setup_data = db.Column(db.JSON, nullable=False)  # JSON with all setup parameters
    weather_condition = db.Column(db.String(50))
    session_type = db.Column(db.String(50))  # practice, qualifying, race
    is_public = db.Column(db.Boolean, default=True)
    is_premium = db.Column(db.Boolean, default=False)
    price = db.Column(db.Numeric(10, 2))  # For paid setups
    download_count = db.Column(db.Integer, default=0)
    rating_average = db.Column(db.Numeric(3, 2), default=0.00)
    rating_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    version = db.Column(db.Integer, default=1)

    # Relationships
    user = db.relationship('User', backref='setups')
    ratings = db.relationship('SetupRating', backref='setup', lazy=True)
    telemetry_sessions = db.relationship('TelemetrySession', backref='setup', lazy=True)
    lap_times = db.relationship('LapTime', backref='setup', lazy=True)

    def __repr__(self):
        return f'<Setup {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'name': self.name,
            'description': self.description,
            'setup_data': self.setup_data,
            'weather_condition': self.weather_condition,
            'session_type': self.session_type,
            'is_public': self.is_public,
            'is_premium': self.is_premium,
            'price': float(self.price) if self.price else None,
            'download_count': self.download_count,
            'rating_average': float(self.rating_average) if self.rating_average else 0.0,
            'rating_count': self.rating_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'version': self.version
        }

class SetupRating(db.Model):
    __tablename__ = 'setup_ratings'
    
    id = db.Column(db.Integer, primary_key=True)
    setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Unique constraint
    __table_args__ = (db.UniqueConstraint('setup_id', 'user_id', name='unique_setup_user_rating'),)

    def __repr__(self):
        return f'<SetupRating {self.rating}>'

    def to_dict(self):
        return {
            'id': self.id,
            'setup_id': self.setup_id,
            'user_id': self.user_id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

