from src.models.user import db
from datetime import datetime
from sqlalchemy import JSON, Numeric, Numeric

class DriverPack(db.Model):
    """
    Modelo para pacotes de setups de pilotos reais
    """
    __tablename__ = 'driver_packs'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_name = db.Column(db.String(100), nullable=False)
    driver_bio = db.Column(db.Text)
    driver_photo_url = db.Column(db.String(255))
    driver_nationality = db.Column(db.String(50))
    driver_category = db.Column(db.String(50))  # 'rookie', 'professional', 'legend', 'superstar'
    
    # Informações do pacote
    pack_name = db.Column(db.String(100), nullable=False)
    pack_description = db.Column(db.Text)
    pack_image_url = db.Column(db.String(255))
    
    # Preços e assinatura
    monthly_price = db.Column(Numeric(10, 2), nullable=False)
    yearly_price = db.Column(Numeric(10, 2))  # Desconto anual
    is_active = db.Column(db.Boolean, default=True)
    
    # Metadados
    total_setups = db.Column(db.Integer, default=0)
    subscriber_count = db.Column(db.Integer, default=0)
    rating_average = db.Column(Numeric(3, 2), default=0.0)
    rating_count = db.Column(db.Integer, default=0)
    
    # Jogos suportados
    supported_games = db.Column(JSON)  # Lista de IDs de jogos
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    setups = db.relationship('DriverPackSetup', backref='driver_pack', lazy=True, cascade='all, delete-orphan')
    subscriptions = db.relationship('DriverPackSubscription', backref='driver_pack', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'driver_name': self.driver_name,
            'driver_bio': self.driver_bio,
            'driver_photo_url': self.driver_photo_url,
            'driver_nationality': self.driver_nationality,
            'driver_category': self.driver_category,
            'pack_name': self.pack_name,
            'pack_description': self.pack_description,
            'pack_image_url': self.pack_image_url,
            'monthly_price': float(self.monthly_price) if self.monthly_price else None,
            'yearly_price': float(self.yearly_price) if self.yearly_price else None,
            'is_active': self.is_active,
            'total_setups': self.total_setups,
            'subscriber_count': self.subscriber_count,
            'rating_average': float(self.rating_average) if self.rating_average else 0.0,
            'rating_count': self.rating_count,
            'supported_games': self.supported_games,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class DriverPackSetup(db.Model):
    """
    Setups específicos de um pacote de piloto
    """
    __tablename__ = 'driver_pack_setups'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_pack_id = db.Column(db.Integer, db.ForeignKey('driver_packs.id'), nullable=False)
    setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'), nullable=False)
    
    # Informações específicas do piloto
    driver_notes = db.Column(db.Text)  # Notas do piloto sobre o setup
    performance_data = db.Column(JSON)  # Dados de performance do piloto com este setup
    video_url = db.Column(db.String(255))  # Link para vídeo explicativo
    
    # Metadados
    is_featured = db.Column(db.Boolean, default=False)  # Setup em destaque do pacote
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    setup = db.relationship('Setup', backref='driver_pack_setups')
    
    def to_dict(self):
        return {
            'id': self.id,
            'driver_pack_id': self.driver_pack_id,
            'setup_id': self.setup_id,
            'driver_notes': self.driver_notes,
            'performance_data': self.performance_data,
            'video_url': self.video_url,
            'is_featured': self.is_featured,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'setup': self.setup.to_dict() if self.setup else None
        }

class DriverPackSubscription(db.Model):
    """
    Assinaturas de usuários para pacotes de pilotos
    """
    __tablename__ = 'driver_pack_subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    driver_pack_id = db.Column(db.Integer, db.ForeignKey('driver_packs.id'), nullable=False)
    
    # Informações da assinatura
    subscription_type = db.Column(db.String(20), nullable=False)  # 'monthly', 'yearly'
    status = db.Column(db.String(20), default='active')  # 'active', 'cancelled', 'expired', 'pending'
    
    # Datas
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    cancelled_at = db.Column(db.DateTime)
    
    # Pagamento
    payment_method = db.Column(db.String(50))  # 'credit_card', 'pix', 'paypal'
    payment_id = db.Column(db.String(100))  # ID do pagamento no gateway
    amount_paid = db.Column(Numeric(10, 2))
    
    # Metadados
    auto_renew = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    user = db.relationship('User', backref='driver_pack_subscriptions')
    
    # Constraint para evitar assinaturas duplicadas ativas
    __table_args__ = (
        db.UniqueConstraint('user_id', 'driver_pack_id', name='unique_active_subscription'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'driver_pack_id': self.driver_pack_id,
            'subscription_type': self.subscription_type,
            'status': self.status,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'payment_method': self.payment_method,
            'payment_id': self.payment_id,
            'amount_paid': float(self.amount_paid) if self.amount_paid else None,
            'auto_renew': self.auto_renew,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class DriverPackRating(db.Model):
    """
    Avaliações de pacotes de pilotos
    """
    __tablename__ = 'driver_pack_ratings'
    
    id = db.Column(db.Integer, primary_key=True)
    driver_pack_id = db.Column(db.Integer, db.ForeignKey('driver_packs.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    rating = db.Column(db.Integer, nullable=False)  # 1-5 estrelas
    comment = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    user = db.relationship('User', backref='driver_pack_ratings')
    driver_pack = db.relationship('DriverPack', backref='ratings')
    
    # Constraint para evitar múltiplas avaliações do mesmo usuário
    __table_args__ = (
        db.UniqueConstraint('driver_pack_id', 'user_id', name='unique_driver_pack_rating'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'driver_pack_id': self.driver_pack_id,
            'user_id': self.user_id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'user': {
                'username': self.user.username,
                'profile_image_url': self.user.profile_image_url
            } if self.user else None
        }

class PremiumFeature(db.Model):
    """
    Funcionalidades premium disponíveis na plataforma
    """
    __tablename__ = 'premium_features'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    feature_key = db.Column(db.String(50), unique=True, nullable=False)  # Chave única para identificar a feature
    
    # Preços
    monthly_price = db.Column(Numeric(10, 2))
    yearly_price = db.Column(Numeric(10, 2))
    
    # Configurações
    is_active = db.Column(db.Boolean, default=True)
    is_standalone = db.Column(db.Boolean, default=True)  # Pode ser comprada separadamente
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'feature_key': self.feature_key,
            'monthly_price': float(self.monthly_price) if self.monthly_price else None,
            'yearly_price': float(self.yearly_price) if self.yearly_price else None,
            'is_active': self.is_active,
            'is_standalone': self.is_standalone,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

