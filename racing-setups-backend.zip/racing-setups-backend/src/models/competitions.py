from src.models.user import db
from datetime import datetime
from sqlalchemy import JSON, Numeric

class Competition(db.Model):
    """
    Modelo para competições da comunidade
    """
    __tablename__ = 'competitions'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações básicas
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    banner_image_url = db.Column(db.String(255))
    
    # Configurações da competição
    competition_type = db.Column(db.String(50), nullable=False)  # 'time_trial', 'race', 'championship', 'setup_battle'
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'))  # Opcional, pode ser livre
    track_id = db.Column(db.Integer, db.ForeignKey('tracks.id'))  # Opcional, pode ser múltiplas pistas
    
    # Condições específicas
    weather_condition = db.Column(db.String(50))  # 'dry', 'wet', 'mixed', 'any'
    session_type = db.Column(db.String(50))  # 'qualifying', 'race', 'practice'
    fuel_restriction = db.Column(db.Integer)  # Litros de combustível máximo
    tire_restriction = db.Column(db.String(50))  # Tipo de pneu obrigatório
    
    # Datas e status
    registration_start = db.Column(db.DateTime, nullable=False)
    registration_end = db.Column(db.DateTime, nullable=False)
    competition_start = db.Column(db.DateTime, nullable=False)
    competition_end = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='upcoming')  # 'upcoming', 'registration_open', 'active', 'finished', 'cancelled'
    
    # Participação
    max_participants = db.Column(db.Integer)  # Limite de participantes
    entry_fee = db.Column(Numeric(10, 2), default=0)  # Taxa de inscrição
    min_skill_level = db.Column(db.String(20))  # Nível mínimo necessário
    
    # Premiação
    total_prize_pool = db.Column(Numeric(10, 2), default=0)
    prize_distribution = db.Column(JSON)  # Distribuição dos prêmios por posição
    sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsors.id'))
    
    # Regras e configurações
    rules = db.Column(db.Text)
    setup_restrictions = db.Column(JSON)  # Restrições específicas de setup
    telemetry_required = db.Column(db.Boolean, default=False)
    
    # Metadados
    participant_count = db.Column(db.Integer, default=0)
    view_count = db.Column(db.Integer, default=0)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    game = db.relationship('Game', backref='competitions')
    car = db.relationship('Car', backref='competitions')
    track = db.relationship('Track', backref='competitions')
    creator = db.relationship('User', backref='created_competitions')
    sponsor = db.relationship('Sponsor', backref='sponsored_competitions')
    participants = db.relationship('CompetitionParticipant', backref='competition', lazy=True, cascade='all, delete-orphan')
    results = db.relationship('CompetitionResult', backref='competition', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'banner_image_url': self.banner_image_url,
            'competition_type': self.competition_type,
            'game_id': self.game_id,
            'car_id': self.car_id,
            'track_id': self.track_id,
            'weather_condition': self.weather_condition,
            'session_type': self.session_type,
            'fuel_restriction': self.fuel_restriction,
            'tire_restriction': self.tire_restriction,
            'registration_start': self.registration_start.isoformat() if self.registration_start else None,
            'registration_end': self.registration_end.isoformat() if self.registration_end else None,
            'competition_start': self.competition_start.isoformat() if self.competition_start else None,
            'competition_end': self.competition_end.isoformat() if self.competition_end else None,
            'status': self.status,
            'max_participants': self.max_participants,
            'entry_fee': float(self.entry_fee) if self.entry_fee else 0,
            'min_skill_level': self.min_skill_level,
            'total_prize_pool': float(self.total_prize_pool) if self.total_prize_pool else 0,
            'prize_distribution': self.prize_distribution,
            'sponsor_id': self.sponsor_id,
            'rules': self.rules,
            'setup_restrictions': self.setup_restrictions,
            'telemetry_required': self.telemetry_required,
            'participant_count': self.participant_count,
            'view_count': self.view_count,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CompetitionParticipant(db.Model):
    """
    Participantes de uma competição
    """
    __tablename__ = 'competition_participants'
    
    id = db.Column(db.Integer, primary_key=True)
    competition_id = db.Column(db.Integer, db.ForeignKey('competitions.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Informações da inscrição
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    setup_id = db.Column(db.Integer, db.ForeignKey('setups.id'))  # Setup usado na competição
    team_name = db.Column(db.String(100))  # Nome da equipe (opcional)
    
    # Status
    status = db.Column(db.String(20), default='registered')  # 'registered', 'confirmed', 'disqualified', 'withdrawn'
    payment_status = db.Column(db.String(20), default='pending')  # 'pending', 'paid', 'refunded'
    payment_id = db.Column(db.String(100))
    
    # Dados de participação
    best_time = db.Column(Numeric(8, 3))  # Melhor tempo registrado
    total_attempts = db.Column(db.Integer, default=0)
    telemetry_submitted = db.Column(db.Boolean, default=False)
    
    # Relacionamentos
    user = db.relationship('User', backref='competition_participations')
    setup = db.relationship('Setup', backref='competition_uses')
    
    # Constraint para evitar inscrições duplicadas
    __table_args__ = (
        db.UniqueConstraint('competition_id', 'user_id', name='unique_competition_participant'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'competition_id': self.competition_id,
            'user_id': self.user_id,
            'registration_date': self.registration_date.isoformat() if self.registration_date else None,
            'setup_id': self.setup_id,
            'team_name': self.team_name,
            'status': self.status,
            'payment_status': self.payment_status,
            'payment_id': self.payment_id,
            'best_time': float(self.best_time) if self.best_time else None,
            'total_attempts': self.total_attempts,
            'telemetry_submitted': self.telemetry_submitted,
            'user': {
                'username': self.user.username,
                'profile_image_url': self.user.profile_image_url,
                'country': self.user.country
            } if self.user else None
        }

class CompetitionResult(db.Model):
    """
    Resultados de uma competição
    """
    __tablename__ = 'competition_results'
    
    id = db.Column(db.Integer, primary_key=True)
    competition_id = db.Column(db.Integer, db.ForeignKey('competitions.id'), nullable=False)
    participant_id = db.Column(db.Integer, db.ForeignKey('competition_participants.id'), nullable=False)
    
    # Resultado
    final_position = db.Column(db.Integer, nullable=False)
    final_time = db.Column(Numeric(8, 3))
    points_earned = db.Column(db.Integer, default=0)
    
    # Prêmio
    prize_amount = db.Column(Numeric(10, 2), default=0)
    prize_description = db.Column(db.String(255))  # Descrição do prêmio (ex: "Volante Logitech G29")
    prize_status = db.Column(db.String(20), default='pending')  # 'pending', 'awarded', 'claimed'
    
    # Dados detalhados
    sector_times = db.Column(JSON)  # Tempos por setor
    telemetry_data = db.Column(JSON)  # Dados de telemetria resumidos
    disqualification_reason = db.Column(db.String(255))
    
    # Metadados
    verified_by = db.Column(db.Integer, db.ForeignKey('users.id'))  # Moderador que verificou
    verified_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    participant = db.relationship('CompetitionParticipant', backref='results')
    verifier = db.relationship('User', backref='verified_results')
    
    def to_dict(self):
        return {
            'id': self.id,
            'competition_id': self.competition_id,
            'participant_id': self.participant_id,
            'final_position': self.final_position,
            'final_time': float(self.final_time) if self.final_time else None,
            'points_earned': self.points_earned,
            'prize_amount': float(self.prize_amount) if self.prize_amount else 0,
            'prize_description': self.prize_description,
            'prize_status': self.prize_status,
            'sector_times': self.sector_times,
            'telemetry_data': self.telemetry_data,
            'disqualification_reason': self.disqualification_reason,
            'verified_by': self.verified_by,
            'verified_at': self.verified_at.isoformat() if self.verified_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Sponsor(db.Model):
    """
    Patrocinadores das competições
    """
    __tablename__ = 'sponsors'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações básicas
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    logo_url = db.Column(db.String(255))
    website_url = db.Column(db.String(255))
    
    # Contato
    contact_email = db.Column(db.String(100))
    contact_phone = db.Column(db.String(20))
    contact_person = db.Column(db.String(100))
    
    # Configurações
    is_active = db.Column(db.Boolean, default=True)
    sponsor_tier = db.Column(db.String(20), default='bronze')  # 'bronze', 'silver', 'gold', 'platinum'
    
    # Estatísticas
    total_sponsored_amount = db.Column(Numeric(12, 2), default=0)
    competitions_sponsored = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'logo_url': self.logo_url,
            'website_url': self.website_url,
            'contact_email': self.contact_email,
            'contact_phone': self.contact_phone,
            'contact_person': self.contact_person,
            'is_active': self.is_active,
            'sponsor_tier': self.sponsor_tier,
            'total_sponsored_amount': float(self.total_sponsored_amount) if self.total_sponsored_amount else 0,
            'competitions_sponsored': self.competitions_sponsored,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CompetitionTemplate(db.Model):
    """
    Templates para criação rápida de competições
    """
    __tablename__ = 'competition_templates'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações básicas
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50))  # 'weekly_challenge', 'monthly_championship', 'special_event'
    
    # Configurações padrão
    default_duration_days = db.Column(db.Integer, default=7)
    default_competition_type = db.Column(db.String(50))
    default_rules = db.Column(db.Text)
    default_prize_structure = db.Column(JSON)
    
    # Restrições
    required_skill_level = db.Column(db.String(20))
    supported_games = db.Column(JSON)  # Lista de IDs de jogos suportados
    
    # Configurações
    is_active = db.Column(db.Boolean, default=True)
    is_recurring = db.Column(db.Boolean, default=False)  # Se deve ser criada automaticamente
    recurrence_pattern = db.Column(db.String(50))  # 'weekly', 'monthly', 'quarterly'
    
    # Metadados
    usage_count = db.Column(db.Integer, default=0)  # Quantas vezes foi usado
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    creator = db.relationship('User', backref='competition_templates')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'default_duration_days': self.default_duration_days,
            'default_competition_type': self.default_competition_type,
            'default_rules': self.default_rules,
            'default_prize_structure': self.default_prize_structure,
            'required_skill_level': self.required_skill_level,
            'supported_games': self.supported_games,
            'is_active': self.is_active,
            'is_recurring': self.is_recurring,
            'recurrence_pattern': self.recurrence_pattern,
            'usage_count': self.usage_count,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Prize(db.Model):
    """
    Prêmios disponíveis para competições
    """
    __tablename__ = 'prizes'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Informações do prêmio
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    image_url = db.Column(db.String(255))
    
    # Tipo e valor
    prize_type = db.Column(db.String(50), nullable=False)  # 'physical', 'digital', 'cash', 'credits'
    monetary_value = db.Column(Numeric(10, 2))
    
    # Disponibilidade
    quantity_available = db.Column(db.Integer, default=1)
    quantity_awarded = db.Column(db.Integer, default=0)
    
    # Fornecedor
    sponsor_id = db.Column(db.Integer, db.ForeignKey('sponsors.id'))
    supplier_info = db.Column(db.Text)  # Informações do fornecedor
    
    # Configurações
    is_active = db.Column(db.Boolean, default=True)
    requires_shipping = db.Column(db.Boolean, default=False)
    shipping_regions = db.Column(JSON)  # Regiões onde pode ser enviado
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    sponsor = db.relationship('Sponsor', backref='provided_prizes')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'image_url': self.image_url,
            'prize_type': self.prize_type,
            'monetary_value': float(self.monetary_value) if self.monetary_value else None,
            'quantity_available': self.quantity_available,
            'quantity_awarded': self.quantity_awarded,
            'sponsor_id': self.sponsor_id,
            'supplier_info': self.supplier_info,
            'is_active': self.is_active,
            'requires_shipping': self.requires_shipping,
            'shipping_regions': self.shipping_regions,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

