from src.models.user import db
from datetime import datetime

class Car(db.Model):
    __tablename__ = 'cars'
    
    id = db.Column(db.Integer, primary_key=True)
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    display_name = db.Column(db.String(100), nullable=False)
    manufacturer = db.Column(db.String(50))
    category = db.Column(db.String(50))  # GT3, GT4, Formula, etc.
    year = db.Column(db.Integer)
    power_hp = db.Column(db.Integer)
    weight_kg = db.Column(db.Integer)
    drivetrain = db.Column(db.String(10))  # FWD, RWD, AWD
    image_url = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    setups = db.relationship('Setup', backref='car', lazy=True)
    telemetry_sessions = db.relationship('TelemetrySession', backref='car', lazy=True)
    lap_times = db.relationship('LapTime', backref='car', lazy=True)

    def __repr__(self):
        return f'<Car {self.display_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'game_id': self.game_id,
            'name': self.name,
            'display_name': self.display_name,
            'manufacturer': self.manufacturer,
            'category': self.category,
            'year': self.year,
            'power_hp': self.power_hp,
            'weight_kg': self.weight_kg,
            'drivetrain': self.drivetrain,
            'image_url': self.image_url,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

