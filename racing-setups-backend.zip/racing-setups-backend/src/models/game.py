from src.models.user import db
from datetime import datetime

class Game(db.Model):
    __tablename__ = 'games'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    display_name = db.Column(db.String(100), nullable=False)
    developer = db.Column(db.String(100))
    api_endpoint = db.Column(db.String(255))  # Endpoint for game API if available
    telemetry_support = db.Column(db.Boolean, default=False)
    icon_url = db.Column(db.String(255))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    tracks = db.relationship('Track', backref='game', lazy=True)
    cars = db.relationship('Car', backref='game', lazy=True)

    def __repr__(self):
        return f'<Game {self.display_name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'display_name': self.display_name,
            'developer': self.developer,
            'api_endpoint': self.api_endpoint,
            'telemetry_support': self.telemetry_support,
            'icon_url': self.icon_url,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

