#!/usr/bin/env python3
"""
Script to seed the database with sample data for testing
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db, User
from src.models.game import Game
from src.models.track import Track
from src.models.car import Car
from src.models.setup import Setup, SetupRating
from src.models.telemetry import TelemetrySession, LapTime
from src.models.community import Forum, ForumTopic, ForumPost, UserFollow, Notification, UserAchievement
from src.main import app

def seed_database():
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        print("Seeding database with sample data...")
        
        # Create sample users
        users = [
            User(username='admin', email='admin@racesetup.com', first_name='Admin', last_name='User', skill_level='professional'),
            User(username='speedking', email='speedking@example.com', first_name='Speed', last_name='King', skill_level='advanced'),
            User(username='racemaster', email='racemaster@example.com', first_name='Race', last_name='Master', skill_level='intermediate'),
            User(username='prodriver', email='prodriver@example.com', first_name='Pro', last_name='Driver', skill_level='advanced'),
            User(username='fastlap', email='fastlap@example.com', first_name='Fast', last_name='Lap', skill_level='intermediate'),
            User(username='turboracer', email='turboracer@example.com', first_name='Turbo', last_name='Racer', skill_level='beginner')
        ]
        
        for user in users:
            user.set_password('password123')
            db.session.add(user)
        
        db.session.commit()
        print(f"Created {len(users)} users")
        
        # Create sample games
        games = [
            Game(name='f1-25', display_name='F1 25', developer='Codemasters', telemetry_support=True, description='Latest Formula 1 racing game'),
            Game(name='iracing', display_name='iRacing', developer='iRacing.com', telemetry_support=True, description='Professional online racing simulation'),
            Game(name='acc', display_name='Assetto Corsa Competizione', developer='Kunos Simulazioni', telemetry_support=True, description='GT racing simulation'),
            Game(name='ac', display_name='Assetto Corsa', developer='Kunos Simulazioni', telemetry_support=True, description='Racing simulation with modding support')
        ]
        
        for game in games:
            db.session.add(game)
        
        db.session.commit()
        print(f"Created {len(games)} games")
        
        # Create sample tracks
        tracks = [
            Track(game_id=1, name='monza', display_name='Monza', country='IT', length_meters=5793, turns_count=11, track_type='circuit'),
            Track(game_id=1, name='silverstone', display_name='Silverstone', country='GB', length_meters=5891, turns_count=18, track_type='circuit'),
            Track(game_id=1, name='spa', display_name='Spa-Francorchamps', country='BE', length_meters=7004, turns_count=19, track_type='circuit'),
            Track(game_id=1, name='monaco', display_name='Monaco', country='MC', length_meters=3337, turns_count=19, track_type='street'),
            Track(game_id=2, name='watkins-glen', display_name='Watkins Glen', country='US', length_meters=5430, turns_count=11, track_type='circuit'),
            Track(game_id=3, name='brands-hatch', display_name='Brands Hatch', country='GB', length_meters=3908, turns_count=12, track_type='circuit')
        ]
        
        for track in tracks:
            db.session.add(track)
        
        db.session.commit()
        print(f"Created {len(tracks)} tracks")
        
        # Create sample cars
        cars = [
            Car(game_id=1, name='ferrari-f1-75', display_name='Ferrari F1-75', manufacturer='Ferrari', category='Formula 1', year=2025, power_hp=1000, weight_kg=798, drivetrain='RWD'),
            Car(game_id=1, name='mercedes-w14', display_name='Mercedes W14', manufacturer='Mercedes', category='Formula 1', year=2025, power_hp=1000, weight_kg=798, drivetrain='RWD'),
            Car(game_id=1, name='redbull-rb19', display_name='Red Bull RB19', manufacturer='Red Bull', category='Formula 1', year=2025, power_hp=1000, weight_kg=798, drivetrain='RWD'),
            Car(game_id=1, name='mclaren-mcl60', display_name='McLaren MCL60', manufacturer='McLaren', category='Formula 1', year=2025, power_hp=1000, weight_kg=798, drivetrain='RWD'),
            Car(game_id=2, name='dallara-ir18', display_name='Dallara IR18', manufacturer='Dallara', category='IndyCar', year=2018, power_hp=700, weight_kg=721, drivetrain='RWD'),
            Car(game_id=3, name='ferrari-488-gt3', display_name='Ferrari 488 GT3', manufacturer='Ferrari', category='GT3', year=2020, power_hp=600, weight_kg=1300, drivetrain='RWD')
        ]
        
        for car in cars:
            db.session.add(car)
        
        db.session.commit()
        print(f"Created {len(cars)} cars")
        
        # Create sample setups
        setups = [
            Setup(
                user_id=2, car_id=1, track_id=1, name='Monza Qualifying Setup',
                description='Setup otimizado para classificação em Monza com baixo downforce',
                setup_data={
                    'aerodynamics': {'front_wing': 2, 'rear_wing': 3},
                    'transmission': {'differential': 85},
                    'suspension': {'front_height': 25, 'rear_height': 30},
                    'brakes': {'pressure': 95, 'bias': 52}
                },
                weather_condition='Seco', session_type='qualifying', rating_average=4.8, rating_count=25, download_count=1250
            ),
            Setup(
                user_id=3, car_id=2, track_id=3, name='Spa Race Setup',
                description='Setup balanceado para corrida em Spa-Francorchamps',
                setup_data={
                    'aerodynamics': {'front_wing': 5, 'rear_wing': 7},
                    'transmission': {'differential': 75},
                    'suspension': {'front_height': 30, 'rear_height': 35},
                    'brakes': {'pressure': 90, 'bias': 54}
                },
                weather_condition='Chuva', session_type='race', rating_average=4.6, rating_count=18, download_count=980
            ),
            Setup(
                user_id=4, car_id=3, track_id=2, name='Silverstone Balanced',
                description='Setup equilibrado para Silverstone em condições secas',
                setup_data={
                    'aerodynamics': {'front_wing': 6, 'rear_wing': 8},
                    'transmission': {'differential': 80},
                    'suspension': {'front_height': 28, 'rear_height': 32},
                    'brakes': {'pressure': 92, 'bias': 53}
                },
                weather_condition='Seco', session_type='race', rating_average=4.9, rating_count=32, download_count=1580
            )
        ]
        
        for setup in setups:
            db.session.add(setup)
        
        db.session.commit()
        print(f"Created {len(setups)} setups")
        
        # Create sample lap times
        lap_times = [
            LapTime(user_id=2, setup_id=1, car_id=1, track_id=1, lap_time=80.543, sector_1_time=25.123, sector_2_time=28.456, sector_3_time=26.964, top_speed=340.5, is_valid=True),
            LapTime(user_id=3, setup_id=2, car_id=2, track_id=3, lap_time=145.687, sector_1_time=48.234, sector_2_time=52.123, sector_3_time=45.330, top_speed=315.2, is_valid=True),
            LapTime(user_id=4, setup_id=3, car_id=3, track_id=2, lap_time=90.821, sector_1_time=28.567, sector_2_time=32.123, sector_3_time=30.131, top_speed=325.8, is_valid=True),
            LapTime(user_id=5, setup_id=1, car_id=4, track_id=1, lap_time=80.954, sector_1_time=25.234, sector_2_time=28.567, sector_3_time=27.153, top_speed=338.9, is_valid=True),
            LapTime(user_id=6, setup_id=1, car_id=1, track_id=1, lap_time=81.123, sector_1_time=25.345, sector_2_time=28.678, sector_3_time=27.100, top_speed=339.2, is_valid=True)
        ]
        
        for lap_time in lap_times:
            db.session.add(lap_time)
        
        db.session.commit()
        print(f"Created {len(lap_times)} lap times")
        
        # Create sample forums
        forums = [
            Forum(name='Discussão Geral', description='Discussões gerais sobre corridas virtuais', category='general'),
            Forum(name='F1 25', description='Discussões sobre F1 25', category='game', game_id=1),
            Forum(name='iRacing', description='Discussões sobre iRacing', category='game', game_id=2),
            Forum(name='Setups e Configurações', description='Compartilhe e discuta setups', category='setups'),
            Forum(name='Telemetria e Análise', description='Análise de dados de telemetria', category='telemetry')
        ]
        
        for forum in forums:
            db.session.add(forum)
        
        db.session.commit()
        print(f"Created {len(forums)} forums")
        
        # Create sample forum topics
        topics = [
            ForumTopic(
                forum_id=1, user_id=2, title='Bem-vindos ao RaceSetup Pro!',
                content='Sejam bem-vindos à nossa comunidade de entusiastas de corridas virtuais!'
            ),
            ForumTopic(
                forum_id=2, user_id=3, title='Melhores setups para Monza',
                content='Vamos discutir os melhores setups para Monza no F1 25. Qual configuração vocês estão usando?'
            ),
            ForumTopic(
                forum_id=4, user_id=4, title='Como ajustar aerodinâmica para pistas rápidas',
                content='Dicas para configurar a aerodinâmica em pistas como Monza e Spa.'
            )
        ]
        
        for topic in topics:
            db.session.add(topic)
        
        db.session.commit()
        print(f"Created {len(topics)} forum topics")
        
        # Create sample forum posts
        posts = [
            ForumPost(topic_id=1, user_id=3, content='Obrigado! Estou ansioso para compartilhar meus setups aqui.'),
            ForumPost(topic_id=1, user_id=4, content='Ótima plataforma! Já baixei alguns setups excelentes.'),
            ForumPost(topic_id=2, user_id=2, content='Para Monza, recomendo baixo downforce e diferencial mais aberto.'),
            ForumPost(topic_id=3, user_id=5, content='Excelente tópico! Vou testar essas configurações.')
        ]
        
        for post in posts:
            db.session.add(post)
        
        # Update topic reply counts
        topics[0].reply_count = 2
        topics[1].reply_count = 1
        topics[2].reply_count = 1
        
        db.session.commit()
        print(f"Created {len(posts)} forum posts")
        
        # Create sample achievements
        achievements = [
            UserAchievement(user_id=2, achievement_type='first_setup', achievement_name='Primeiro Setup', description='Criou seu primeiro setup'),
            UserAchievement(user_id=2, achievement_type='speed_demon', achievement_name='Demônio da Velocidade', description='Registrou tempo abaixo de 1:21 em Monza'),
            UserAchievement(user_id=3, achievement_type='community_helper', achievement_name='Ajudante da Comunidade', description='Fez 10 posts no fórum'),
            UserAchievement(user_id=4, achievement_type='setup_master', achievement_name='Mestre dos Setups', description='Criou 5 setups com rating acima de 4.5')
        ]
        
        for achievement in achievements:
            db.session.add(achievement)
        
        db.session.commit()
        print(f"Created {len(achievements)} achievements")
        
        print("Database seeded successfully!")

if __name__ == '__main__':
    seed_database()

